"""Generate logistics_data.json, emergency_data.json, operators_data.json from coastal_data."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "tidewise" / "data"


def main():
    coastal = json.loads((DATA / "coastal_data.json").read_text(encoding="utf-8"))
    ids = [d["id"] for d in coastal["destinations"]]

    nodes = [{"id": i, "label": next(d["name"] for d in coastal["destinations"] if d["id"] == i), "type": "mainland_hub"} for i in ids]
    for n in nodes:
        if "island" in n["id"] or "agatti" in n["id"] or "neil" in n["id"]:
            n["type"] = "island"
        if "port_blair" in n["id"] or "kochi" in n["id"]:
            n["type"] = "ferry_hub"
        if "grand_island" in n["id"] or "gokarna_islands" in n["id"]:
            n["type"] = "boat_hub"

    edges = [
        {"from": "goa_calangute", "to": "goa_grand_island", "mode": "boat_transfer", "duration_min": 45, "cost_inr_per_person": 800, "notes": "Scuba/snorkel day trips from Sinquerim/Coco"},
        {"from": "goa_grand_island", "to": "goa_calangute", "mode": "boat_transfer", "duration_min": 45, "cost_inr_per_person": 800, "notes": "return"},
        {"from": "goa_palolem", "to": "goa_grand_island", "mode": "boat_transfer", "duration_min": 90, "cost_inr_per_person": 1200, "notes": "Long day trip — less common"},
        {"from": "andaman_port_blair", "to": "andaman_havelock", "mode": "ferry", "duration_min": 120, "cost_inr_per_person": 1500, "notes": "Govt/private ferries"},
        {"from": "andaman_havelock", "to": "andaman_port_blair", "mode": "ferry", "duration_min": 120, "cost_inr_per_person": 1500, "notes": "return"},
        {"from": "andaman_havelock", "to": "andaman_neil", "mode": "ferry", "duration_min": 60, "cost_inr_per_person": 600, "notes": "Island hop"},
        {"from": "andaman_neil", "to": "andaman_havelock", "mode": "ferry", "duration_min": 60, "cost_inr_per_person": 600, "notes": "return"},
        {"from": "karnataka_gokarna", "to": "gokarna_islands", "mode": "boat_transfer", "duration_min": 30, "cost_inr_per_person": 500, "notes": "Coastal rock/island views"},
        {"from": "gokarna_islands", "to": "karnataka_gokarna", "mode": "boat_transfer", "duration_min": 30, "cost_inr_per_person": 500, "notes": "return"},
        {"from": "karnataka_malpe", "to": "karnataka_st_marys", "mode": "ferry", "duration_min": 40, "cost_inr_per_person": 400, "notes": "St. Mary's Islands ferry"},
        {"from": "karnataka_st_marys", "to": "karnataka_malpe", "mode": "ferry", "duration_min": 40, "cost_inr_per_person": 400, "notes": "return"},
        {"from": "lakshadweep_kochi", "to": "lakshadweep_agatti", "mode": "flight_ferry_combo", "duration_min": 240, "cost_inr_per_person": 8000, "notes": "Permit-gated; indicative"},
        {"from": "lakshadweep_agatti", "to": "lakshadweep_kochi", "mode": "flight_ferry_combo", "duration_min": 240, "cost_inr_per_person": 8000, "notes": "return"},
    ]
    nodes.append({"id": "gokarna_islands", "label": "Offshore rock clusters", "type": "boat_hub"})
    nodes.append({"id": "karnataka_st_marys", "label": "St. Mary's Islands", "type": "island"})
    nodes.append({"id": "lakshadweep_kochi", "label": "Kochi gateway", "type": "ferry_hub"})

    (DATA / "logistics_data.json").write_text(
        json.dumps({"schema_version": "2.0", "nodes": nodes, "edges": edges}, indent=2),
        encoding="utf-8",
    )

    emergency = {"schema_version": "1.0", "by_destination_id": {}}
    operators = {"schema_version": "1.0", "by_destination_id": {}}

    for d in coastal["destinations"]:
        did = d["id"]
        st = d["state"]
        emergency["by_destination_id"][did] = {
            "national_emergency": "112",
            "coastal_police": "100 / state coastal helpline",
            "indian_coast_guard": "1554 (toll-free maritime search & rescue — verify locally)",
            "nearest_hospital_hint": f"District hospital / PHC in {d['region_label']} — confirm on arrival",
            "ambulance": "108 (state-dependent)",
            "disaster_mgmt_note": "Follow state IMD cyclone bulletins; do not enter water under red alerts.",
        }
        operators["by_destination_id"][did] = [
            {
                "name": f"{d['name'][:20]} Adventure Collective (sim.)",
                "type": "watersports_operator",
                "services": d.get("activities_available", [])[:4],
                "indicative_rating": round(4.2 + (hash(did) % 8) / 10, 1),
                "phone_placeholder": "+91-80XXXXXX00",
                "cert_note": "Verify PADI/SSI or ISA certifications before scuba/surf lessons.",
            },
            {
                "name": f"Coastal Gear & Rentals — {d['region_label']}",
                "type": "equipment_vendor",
                "services": ["life_jackets", "snorkel_sets", "kayak_hire"],
                "indicative_rating": 4.4,
                "phone_placeholder": "+91-90XXXXXX00",
            },
        ]

    (DATA / "emergency_data.json").write_text(json.dumps(emergency, indent=2), encoding="utf-8")
    (DATA / "operators_data.json").write_text(json.dumps(operators, indent=2), encoding="utf-8")
    print("Wrote logistics, emergency, operators")


if __name__ == "__main__":
    main()
