import os
import re

# 1. Update index.html
html_file = 'static/index.html'
with open(html_file, 'r', encoding='utf-8') as f:
    html = f.read()

# Booking Modal Phone Number
html = html.replace(
    '<input type="email" id="booking-email" placeholder="example@email.com" class="ui-input mt-2" required />',
    '<input type="email" id="booking-email" placeholder="example@email.com" class="ui-input mt-2" required />\n        <input type="text" id="booking-phone" placeholder="Phone Number" class="ui-input mt-2" required />'
)

# Sidebar links IDs
sidebar_replacements = [
    ('>\\s*Flights\\s*</a>', ' onclick="openServicePanel(\'flight\')">Flights</a>'),
    ('>\\s*Hotels\\s*</a>', ' onclick="openServicePanel(\'hotel\')">Hotels</a>'),
    ('>\\s*Bus\\s*</a>', ' onclick="openServicePanel(\'bus\')">Bus</a>'),
    ('>\\s*Cruise\\s*</a>', ' onclick="openServicePanel(\'cruise\')">Cruise</a>'),
    ('>\\s*Cabs\\s*</a>', ' onclick="openServicePanel(\'cab\')">Cabs</a>'),
    ('>\\s*Tours &amp; Attractions\\s*</a>', ' onclick="openServicePanel(\'tours\')">Tours &amp; Attractions</a>'),
    ('>\\s*Villas &amp; Homestays\\s*</a>', ' onclick="openServicePanel(\'villas\')">Villas &amp; Homestays</a>'),
]
for old, new in sidebar_replacements:
    html = re.sub(old, new, html)

# Add Service Panel Modal and Modify Plan Modal
modals_html = """
  <!-- Service Panel Modal -->
  <div id="service-panel-modal" class="modal-overlay" style="display: none;">
    <div class="modal-content" style="max-width: 700px;">
      <div class="modal-header">
        <h2 id="sp-title">Book Service</h2>
        <button type="button" class="close-modal" aria-label="Close modal" onclick="document.getElementById('service-panel-modal').style.display='none'">&times;</button>
      </div>
      <div class="modal-body">
        <form id="sp-form">
          <input type="hidden" id="sp-type" />
          <div class="form-grid">
            <div class="form-group"><label>📍 Location</label><input type="text" id="sp-location" class="ui-input" required /></div>
            <div class="form-group"><label>📅 Date</label><input type="date" id="sp-date" class="ui-input" required /></div>
            <div class="form-group"><label>🧍 People</label><input type="number" id="sp-people" class="ui-input" value="1" min="1" required /></div>
            <div class="form-group"><label>💰 Budget</label><input type="text" id="sp-budget" class="ui-input" placeholder="Optional" /></div>
          </div>
          <button type="button" class="btn-primary mt-3 ripple-surface" onclick="searchService()">Search & Filter</button>
        </form>
        <div id="sp-results" class="mt-4" style="display: none;">
           <h4>Available Options</h4>
           <div id="sp-results-list" class="vendor-cards-row" style="flex-direction: column;"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- Modify Plan Modal -->
  <div id="modify-plan-modal" class="modal-overlay" style="display: none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Modify Active Plan</h2>
        <button type="button" class="close-modal" onclick="document.getElementById('modify-plan-modal').style.display='none'">&times;</button>
      </div>
      <div class="modal-body">
        <p>Change your constraints mid-plan to instantly recompute safety, logistics, and itinerary.</p>
        <div class="form-group mt-2"><label>New Budget (₹)</label><input type="number" id="mod-budget" class="ui-input" /></div>
        <div class="form-group mt-2"><label>Add Activities (comma separated)</label><input type="text" id="mod-activities" class="ui-input" placeholder="e.g. Parasailing, Jet Skiing" /></div>
        <button type="button" class="btn-primary mt-3" onclick="submitModifyPlan()">Apply Changes</button>
      </div>
    </div>
  </div>
"""
html = html.replace('<!-- Booking Modal -->', modals_html + '\n  <!-- Booking Modal -->')

with open(html_file, 'w', encoding='utf-8') as f:
    f.write(html)


# 2. Update app.js
js_file = 'static/app.js'
with open(js_file, 'r', encoding='utf-8') as f:
    js = f.read()

# Update submitBooking
js = js.replace('const email = $("#booking-email").value;', 'const email = $("#booking-email").value;\n  const phone = $("#booking-phone") ? $("#booking-phone").value : "";')
js = js.replace('email: email,', 'email: email,\n        phone: phone,')

# Add Modify Plan Button to renderSummary
mod_btn = '<button type="button" class="btn-primary mt-3" onclick="document.getElementById(\\\'modify-plan-modal\\\').style.display=\\\'flex\\\'">Modify Plan Constraints</button>'
js = js.replace('${breakdownHtml}', '${breakdownHtml}\n    ' + mod_btn)

# Image Improvement
img_replacement = """
    const curatedImages = {
      "scuba": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=400&q=80",
      "snorkeling": "https://images.unsplash.com/photo-1582967788606-a171c1080cb0?auto=format&fit=crop&w=400&q=80",
      "surfing": "https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=400&q=80",
      "kayaking": "https://images.unsplash.com/photo-1527269534026-c86f4009eace?auto=format&fit=crop&w=400&q=80",
      "island": "https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?auto=format&fit=crop&w=400&q=80",
      "horse": "https://images.unsplash.com/photo-1553193498-85e656649fc6?auto=format&fit=crop&w=400&q=80",
      "jet": "https://images.unsplash.com/photo-1522869151528-98e604f8dd2e?auto=format&fit=crop&w=400&q=80",
      "parasailing": "https://images.unsplash.com/photo-1528150212001-f2f2549a7122?auto=format&fit=crop&w=400&q=80",
      "banana": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=400&q=80",
      "paddleboarding": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=400&q=80",
      "atv": "https://images.unsplash.com/photo-1522869151528-98e604f8dd2e?auto=format&fit=crop&w=400&q=80"
    };
    let imgSrc = curatedImages[keyword] || `https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=400&q=80`;
"""
js = js.replace('let imgSrc = `https://loremflickr.com/400/250/${encodeURIComponent(keyword)},beach/all`;', img_replacement)


# Append new JS logic
new_js = """

// --- Service Panel & Booking System ---
window.openServicePanel = function(type) {
  const titles = {
    flight: "Book Flights", hotel: "Book Hotels", bus: "Book Bus", 
    cruise: "Book Cruise", cab: "Book Cabs", tours: "Tours & Attractions", villas: "Villas & Homestays"
  };
  $("#sp-title").textContent = titles[type];
  $("#sp-type").value = type;
  $("#sp-results").style.display = "none";
  $("#service-panel-modal").style.display = "flex";
}

window.searchService = function() {
  const type = $("#sp-type").value;
  const loc = $("#sp-location").value;
  const date = $("#sp-date").value;
  
  if(!loc || !date) { alert("Location and Date required"); return; }
  
  const providers = {
    flight: ["IndiGo", "Air India", "SpiceJet"],
    hotel: ["Taj Exotica", "Marriott Resort", "Local Sea View Inn"],
    bus: ["Volvo Express", "Sleeper Lines", "Coastal Transports"],
    cruise: ["Oceania Cruises", "Coastal Ferries", "Luxury Yachts"],
    cab: ["Uber Coastal", "Ola Outstation", "Local Taxi Service"],
    tours: ["City Heritage", "Island Explorer", "Temple Trails"],
    villas: ["Oceanfront Villa", "Cozy Homestay", "Luxury Retreat"]
  };
  
  const basePrices = { flight: 4500, hotel: 3000, bus: 800, cruise: 6000, cab: 1500, tours: 1200, villas: 8000 };
  
  let html = '';
  providers[type].forEach((p, i) => {
    const price = `₹${basePrices[type] + i*500}`;
    html += `
      <div class="vendor-card" style="padding: 1rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 6px;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <h4 style="margin:0">${p}</h4>
            <p style="margin:0; font-size: 0.9em;">Price: ${price}</p>
          </div>
          <button class="btn-primary" onclick="confirmServiceBooking('${type}', '${p}', '${price}')">Book Now</button>
        </div>
      </div>
    `;
  });
  
  $("#sp-results-list").innerHTML = html;
  $("#sp-results").style.display = "block";
}

window.confirmServiceBooking = async function(type, vendor, price) {
  const email = prompt("Enter your email for confirmation:");
  if(!email) return;
  const phone = prompt("Enter your phone number (optional):") || "";
  
  try {
    const res = await fetch(`/api/book/${type}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email, phone, vendor, price, 
        activity: type + " booking",
        date: $("#sp-date").value,
        location: $("#sp-location").value,
        people: parseInt($("#sp-people").value)
      })
    });
    const data = await res.json();
    alert("Success! " + data.message + " Booking ID: " + data.booking_id);
    $("#service-panel-modal").style.display = "none";
  } catch(e) {
    alert("Error: " + e.message);
  }
}

// --- Modify Plan ---
window.submitModifyPlan = async function() {
  const q = "Modified plan request.";
  const budget = $("#mod-budget").value;
  const acts = $("#mod-activities").value;
  
  const changes = {};
  if(budget) changes.budget = parseInt(budget);
  if(acts) changes.add_activities = acts.split(',').map(s=>s.trim());
  
  $("#hero-status").textContent = "⏳ Adaptive Planning Agent is recomputing your itinerary...";
  $("#modify-plan-modal").style.display = "none";
  document.getElementById("sec-dest").scrollIntoView({ behavior: "smooth", block: "start" });
  
  try {
    const res = await fetch("/api/plan/modify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: q, changes: changes })
    });
    const data = await res.json();
    const trip = data.trip || {};
    
    // We update only itinerary and budget sections visually to show "BEFORE vs AFTER" if we had the old state
    // But re-rendering the whole plan also achieves the instant recomputation goal.
    renderLogistics(trip.logistics_and_budget || {});
    renderItinerary(trip.adaptive_itinerary || {});
    renderSummary(trip.trip_intelligence_summary || {}, trip.logistics_and_budget || {});
    
    alert("Plan successfully modified!");
  } catch (e) {
    alert("Error modifying plan: " + e.message);
  }
}

// --- Fetch Budget Breakdown ---
window.fetchBudgetBreakdown = async function() {
  // Can be called to get dynamic breakdown
  const lb = window.current_logistics_budget; 
  if(!lb) return;
  const res = await fetch("/api/budget/breakdown", {
     method: "POST",
     headers: {"Content-Type": "application/json"},
     body: JSON.stringify({
         total_budget: lb.estimated_total_inr || 0,
         duration_days: 4,
         group_size: 2
     })
  });
  const data = await res.json();
  console.log("Detailed Breakdown:", data);
}
"""

with open(js_file, 'a', encoding='utf-8') as f:
    f.write(new_js)

