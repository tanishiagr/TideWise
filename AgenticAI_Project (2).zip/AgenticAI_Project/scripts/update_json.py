import json
import os

activity_file = 'tidewise/data/activity_data.json'
with open(activity_file, 'r') as f:
    act_data = json.load(f)

new_activities = [
    {
      "id": "horse_riding",
      "display_name": "Horse Riding on Beach",
      "risk_score": 1,
      "min_visibility_m": 1,
      "max_wave_height_m": 5.0,
      "max_wind_knots": 25,
      "symbolic_rules": [
        "IF tide_strength == strong THEN restrict_to_high_ground"
      ],
      "typical_cost_inr": 800,
      "experience_weight": 4
    },
    {
      "id": "jet_skiing",
      "display_name": "Jet Skiing",
      "risk_score": 3,
      "min_visibility_m": 3,
      "max_wave_height_m": 1.5,
      "max_wind_knots": 20,
      "symbolic_rules": [
        "IF wave_height_m > max_wave_height_m THEN block_activity"
      ],
      "typical_cost_inr": 1500,
      "experience_weight": 7
    },
    {
      "id": "parasailing",
      "display_name": "Parasailing",
      "risk_score": 4,
      "min_visibility_m": 5,
      "max_wave_height_m": 1.2,
      "max_wind_knots": 18,
      "symbolic_rules": [
        "IF wind_knots > max_wind_knots THEN block_activity"
      ],
      "typical_cost_inr": 2000,
      "experience_weight": 8
    },
    {
      "id": "banana_boat",
      "display_name": "Banana Boat Ride",
      "risk_score": 2,
      "min_visibility_m": 3,
      "max_wave_height_m": 1.0,
      "max_wind_knots": 15,
      "symbolic_rules": [
        "IF wave_height_m > max_wave_height_m THEN block_activity"
      ],
      "typical_cost_inr": 600,
      "experience_weight": 5
    },
    {
      "id": "paddleboarding",
      "display_name": "Stand-up Paddleboarding",
      "risk_score": 2,
      "min_visibility_m": 2,
      "max_wave_height_m": 0.5,
      "max_wind_knots": 12,
      "symbolic_rules": [
        "IF wave_height_m > max_wave_height_m THEN block_activity"
      ],
      "typical_cost_inr": 1000,
      "experience_weight": 6
    },
    {
      "id": "atv_rides",
      "display_name": "Beach ATV rides",
      "risk_score": 2,
      "min_visibility_m": 1,
      "max_wave_height_m": 5.0,
      "max_wind_knots": 25,
      "symbolic_rules": [
        "IF tide == high THEN block_activity"
      ],
      "typical_cost_inr": 1200,
      "experience_weight": 6
    }
]

existing_ids = [a['id'] for a in act_data['activities']]
for a in new_activities:
    if a['id'] not in existing_ids:
        act_data['activities'].append(a)

with open(activity_file, 'w') as f:
    json.dump(act_data, f, indent=2)

coastal_file = 'tidewise/data/coastal_data.json'
with open(coastal_file, 'r') as f:
    coast_data = json.load(f)

new_destinations = [
    {
      "id": "karnataka_udupi",
      "name": "Udupi Coast",
      "state": "Karnataka",
      "region_label": "Udupi",
      "latitude": 13.3409,
      "longitude": 74.7421,
      "description": "Temple town coast with pristine beaches and surfing schools.",
      "water_temp_c_min": 27,
      "water_temp_c_max": 29,
      "visibility_typical_m": 6,
      "avg_wave_height_m_typical": 0.8,
      "crowd_level": "moderate",
      "crowd_index": 6,
      "activities_available": ["surfing", "kayaking", "banana_boat", "jet_skiing"],
      "avg_daily_cost_inr": 3500,
      "tide_profile": "moderate_semidiurnal",
      "weather_status": "tropical_coastal",
      "base_risk_level": "low",
      "swell_typical_m": 0.7
    },
    {
      "id": "gujarat_diu",
      "name": "Diu Island",
      "state": "Daman & Diu",
      "region_label": "Diu",
      "latitude": 20.7144,
      "longitude": 70.9874,
      "description": "Portuguese heritage island with calm Nagoa beach.",
      "water_temp_c_min": 25,
      "water_temp_c_max": 28,
      "visibility_typical_m": 5,
      "avg_wave_height_m_typical": 0.6,
      "crowd_level": "moderate",
      "crowd_index": 5,
      "activities_available": ["parasailing", "jet_skiing", "banana_boat"],
      "avg_daily_cost_inr": 3000,
      "tide_profile": "moderate_semidiurnal",
      "weather_status": "tropical_coastal",
      "base_risk_level": "low",
      "swell_typical_m": 0.5
    },
    {
      "id": "maharashtra_alibaug",
      "name": "Alibaug",
      "state": "Maharashtra",
      "region_label": "Konkan",
      "latitude": 18.6414,
      "longitude": 72.8722,
      "description": "Weekend getaway from Mumbai with black sand beaches and water sports.",
      "water_temp_c_min": 26,
      "water_temp_c_max": 29,
      "visibility_typical_m": 3,
      "avg_wave_height_m_typical": 0.7,
      "crowd_level": "high",
      "crowd_index": 8,
      "activities_available": ["jet_skiing", "banana_boat", "atv_rides", "horse_riding"],
      "avg_daily_cost_inr": 4000,
      "tide_profile": "moderate_semidiurnal",
      "weather_status": "tropical_coastal",
      "base_risk_level": "medium",
      "swell_typical_m": 0.6
    },
    {
      "id": "maharashtra_tarkarli",
      "name": "Tarkarli",
      "state": "Maharashtra",
      "region_label": "Sindhudurg",
      "latitude": 16.0274,
      "longitude": 73.4831,
      "description": "Clear waters famous for scuba diving and backwaters.",
      "water_temp_c_min": 26,
      "water_temp_c_max": 29,
      "visibility_typical_m": 8,
      "avg_wave_height_m_typical": 0.5,
      "crowd_level": "moderate",
      "crowd_index": 6,
      "activities_available": ["scuba_diving", "snorkeling", "parasailing"],
      "avg_daily_cost_inr": 3800,
      "tide_profile": "moderate_semidiurnal",
      "weather_status": "tropical_coastal",
      "base_risk_level": "low",
      "swell_typical_m": 0.4
    },
    {
      "id": "maharashtra_dapoli",
      "name": "Dapoli",
      "state": "Maharashtra",
      "region_label": "Ratnagiri",
      "latitude": 17.7684,
      "longitude": 73.1812,
      "description": "Quiet Konkan stretch with dolphin sightings.",
      "water_temp_c_min": 26,
      "water_temp_c_max": 29,
      "visibility_typical_m": 5,
      "avg_wave_height_m_typical": 0.6,
      "crowd_level": "low",
      "crowd_index": 3,
      "activities_available": ["banana_boat", "jet_skiing"],
      "avg_daily_cost_inr": 3200,
      "tide_profile": "moderate_semidiurnal",
      "weather_status": "tropical_coastal",
      "base_risk_level": "low",
      "swell_typical_m": 0.5
    },
    {
      "id": "karnataka_karwar",
      "name": "Karwar",
      "state": "Karnataka",
      "region_label": "Uttara Kannada",
      "latitude": 14.8185,
      "longitude": 74.1416,
      "description": "Scenic harbor town with islands and pristine beaches.",
      "water_temp_c_min": 27,
      "water_temp_c_max": 29,
      "visibility_typical_m": 7,
      "avg_wave_height_m_typical": 0.5,
      "crowd_level": "low",
      "crowd_index": 4,
      "activities_available": ["kayaking", "island_hopping", "snorkeling"],
      "avg_daily_cost_inr": 3400,
      "tide_profile": "moderate_semidiurnal",
      "weather_status": "tropical_coastal",
      "base_risk_level": "low",
      "swell_typical_m": 0.4
    },
    {
      "id": "ap_vizag",
      "name": "Visakhapatnam (Vizag)",
      "state": "Andhra Pradesh",
      "region_label": "Visakhapatnam",
      "latitude": 17.6868,
      "longitude": 83.2185,
      "description": "City of Destiny with hills meeting the sea and submarine museum.",
      "water_temp_c_min": 27,
      "water_temp_c_max": 30,
      "visibility_typical_m": 5,
      "avg_wave_height_m_typical": 0.8,
      "crowd_level": "high",
      "crowd_index": 8,
      "activities_available": ["jet_skiing", "parasailing", "scuba_diving"],
      "avg_daily_cost_inr": 4200,
      "tide_profile": "moderate_semidiurnal",
      "weather_status": "tropical_coastal",
      "base_risk_level": "medium",
      "swell_typical_m": 0.7
    }
]

existing_coastal = [d['id'] for d in coast_data['destinations']]
for d in new_destinations:
    if d['id'] not in existing_coastal:
        coast_data['destinations'].append(d)

for d in coast_data['destinations']:
    d['activities_available'] = list(set(d.get('activities_available', []) + ["horse_riding", "jet_skiing", "parasailing", "banana_boat", "paddleboarding", "atv_rides"]))

with open(coastal_file, 'w') as f:
    json.dump(coast_data, f, indent=2)
