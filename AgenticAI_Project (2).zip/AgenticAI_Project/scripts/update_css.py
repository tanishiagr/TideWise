import os

css_file = 'static/app.css'
new_css = """
/* Enhancements for Left Panel & Modals */
.modal-overlay {
  background: rgba(10, 25, 47, 0.75);
  backdrop-filter: blur(4px);
  transition: opacity 0.3s ease;
}

.modal-content {
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.2);
  transform: translateY(0);
  animation: slideUp 0.3s ease-out;
}

@keyframes slideUp {
  from { transform: translateY(20px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
}

.sidebar-link {
  transition: all 0.2s ease-in-out;
}

.sidebar-link:hover {
  background-color: var(--sea-mid);
  color: white;
  transform: translateX(5px);
  border-radius: 8px;
}

.vendor-card {
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.vendor-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 20px rgba(42, 122, 140, 0.15);
}

.gw-marine-info {
  border-left: 4px solid var(--sea-mid);
  padding-left: 1rem;
}
"""

with open(css_file, 'a', encoding='utf-8') as f:
    f.write(new_css)
