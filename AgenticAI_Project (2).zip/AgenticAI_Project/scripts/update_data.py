import json
from pathlib import Path

data_dir = Path("c:/Users/Preshru/Desktop/AgenticAI_Project/tidewise/data")
activity_path = data_dir / "activity_data.json"
coastal_path = data_dir / "coastal_data.json"

# Update Activities
with open(activity_path, "r", encoding="utf-8") as f:
    act_data = json.load(f)

new_activities = [
    {
      "id": "horse_riding",
      "display_name": "Horse Riding on Beach",
      "risk_score": 2,
      "min_visibility_m": 1,
      "max_wave_height_m": 5.0,
      "max_wind_knots": 25,
      "symbolic_rules": ["IF weather == stormy THEN block_activity"],
      "typical_cost_inr": 800,
      "experience_weight": 4
    },
    {
      "id": "jet_skiing",
      "display_name": "Jet Skiing",
      "risk_score": 4,
      "min_visibility_m": 2,
      "max_wave_height_m": 1.5,
      "max_wind_knots": 20,
      "symbolic_rules": ["IF visibility_m < min_visibility_m THEN block_activity", "IF wave_height_m > max_wave_height_m THEN block_activity"],
      "typical_cost_inr": 1500,
      "experience_weight": 8
    },
    {
      "id": "parasailing",
      "display_name": "Parasailing",
      "risk_score": 3,
      "min_visibility_m": 3,
      "max_wave_height_m": 1.5,
      "max_wind_knots": 15,
      "symbolic_rules": ["IF wind_knots > max_wind_knots THEN block_activity"],
      "typical_cost_inr": 1800,
      "experience_weight": 7
    },
    {
      "id": "banana_boat",
      "display_name": "Banana Boat Ride",
      "risk_score": 2,
      "min_visibility_m": 2,
      "max_wave_height_m": 1.2,
      "max_wind_knots": 18,
      "symbolic_rules": ["IF wave_height_m > max_wave_height_m THEN block_activity"],
      "typical_cost_inr": 600,
      "experience_weight": 5
    },
    {
      "id": "sup",
      "display_name": "Stand-up Paddleboarding",
      "risk_score": 2,
      "min_visibility_m": 2,
      "max_wave_height_m": 0.8,
      "max_wind_knots": 12,
      "symbolic_rules": ["IF wind_knots > max_wind_knots THEN block_activity"],
      "typical_cost_inr": 1000,
      "experience_weight": 5
    },
    {
      "id": "atv",
      "display_name": "Beach ATV rides",
      "risk_score": 3,
      "min_visibility_m": 1,
      "max_wave_height_m": 5.0,
      "max_wind_knots": 30,
      "symbolic_rules": ["IF weather == stormy THEN block_activity"],
      "typical_cost_inr": 1200,
      "experience_weight": 6
    }
]

existing_act_ids = {a["id"] for a in act_data["activities"]}
for a in new_activities:
    if a["id"] not in existing_act_ids:
        act_data["activities"].append(a)

with open(activity_path, "w", encoding="utf-8") as f:
    json.dump(act_data, f, indent=2)

# Update Coastal Data
with open(coastal_path, "r", encoding="utf-8") as f:
    coastal_data = json.load(f)

new_destinations = [
    {
      "id": "karnataka_udupi",
      "name": "Udupi",
      "state": "Karnataka",
      "region_label": "Udupi",
      "latitude": 13.3409,
      "longitude": 74.7421,
      "description": "Temple town known for serene beaches and culinary heritage.",
      "water_temp_c_min": 27, "water_temp_c_max": 29,
      "visibility_typical_m": 6, "avg_wave_height_m_typical": 0.8,
      "crowd_level": "moderate", "crowd_index": 5,
      "activities_available": ["scuba_diving", "snorkeling", "jet_skiing", "parasailing"],
      "avg_daily_cost_inr": 4000,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.7,
      "highlights": ["Udupi", "Karnataka"],
      "best_months": [10, 11, 12, 1, 2, 3]
    },
    {
      "id": "diu_island",
      "name": "Diu",
      "state": "Daman & Diu",
      "region_label": "Diu",
      "latitude": 20.7144,
      "longitude": 70.9874,
      "description": "Portuguese heritage island with clean beaches like Nagoa and Ghoghla.",
      "water_temp_c_min": 24, "water_temp_c_max": 28,
      "visibility_typical_m": 5, "avg_wave_height_m_typical": 0.6,
      "crowd_level": "high", "crowd_index": 7,
      "activities_available": ["parasailing", "jet_skiing", "banana_boat", "atv"],
      "avg_daily_cost_inr": 4500,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.5,
      "highlights": ["Diu", "Daman & Diu"],
      "best_months": [10, 11, 12, 1, 2]
    },
    {
      "id": "maharashtra_alibaug",
      "name": "Alibaug",
      "state": "Maharashtra",
      "region_label": "Raigad",
      "latitude": 18.6414,
      "longitude": 72.8722,
      "description": "Popular weekend getaway from Mumbai with black sand beaches.",
      "water_temp_c_min": 25, "water_temp_c_max": 29,
      "visibility_typical_m": 3, "avg_wave_height_m_typical": 0.7,
      "crowd_level": "very_high", "crowd_index": 9,
      "activities_available": ["banana_boat", "jet_skiing", "horse_riding", "atv"],
      "avg_daily_cost_inr": 5500,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.6,
      "highlights": ["Raigad", "Maharashtra"],
      "best_months": [10, 11, 12, 1, 2, 3]
    },
    {
      "id": "maharashtra_tarkarli",
      "name": "Tarkarli",
      "state": "Maharashtra",
      "region_label": "Sindhudurg",
      "latitude": 16.0357,
      "longitude": 73.4839,
      "description": "Clear water beaches and backwaters, famous for scuba and Sindhudurg fort.",
      "water_temp_c_min": 26, "water_temp_c_max": 29,
      "visibility_typical_m": 8, "avg_wave_height_m_typical": 0.6,
      "crowd_level": "moderate", "crowd_index": 6,
      "activities_available": ["scuba_diving", "snorkeling", "parasailing", "banana_boat"],
      "avg_daily_cost_inr": 4200,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.5,
      "highlights": ["Sindhudurg", "Maharashtra"],
      "best_months": [10, 11, 12, 1, 2, 3]
    },
    {
      "id": "maharashtra_dapoli",
      "name": "Dapoli",
      "state": "Maharashtra",
      "region_label": "Ratnagiri",
      "latitude": 17.7667,
      "longitude": 73.1833,
      "description": "Known as mini-Mahabaleshwar, features dolphin sightings and uncrowded beaches.",
      "water_temp_c_min": 26, "water_temp_c_max": 29,
      "visibility_typical_m": 5, "avg_wave_height_m_typical": 0.6,
      "crowd_level": "low", "crowd_index": 4,
      "activities_available": ["banana_boat", "atv", "parasailing"],
      "avg_daily_cost_inr": 3800,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.5,
      "highlights": ["Ratnagiri", "Maharashtra"],
      "best_months": [10, 11, 12, 1, 2]
    },
    {
      "id": "karnataka_karwar",
      "name": "Karwar",
      "state": "Karnataka",
      "region_label": "Uttara Kannada",
      "latitude": 14.8037,
      "longitude": 74.1345,
      "description": "Scenic harbor town with islands and Rabindranath Tagore beach.",
      "water_temp_c_min": 27, "water_temp_c_max": 29,
      "visibility_typical_m": 6, "avg_wave_height_m_typical": 0.8,
      "crowd_level": "low", "crowd_index": 3,
      "activities_available": ["snorkeling", "kayaking", "island_hopping"],
      "avg_daily_cost_inr": 3500,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.7,
      "highlights": ["Uttara Kannada", "Karnataka"],
      "best_months": [10, 11, 12, 1, 2]
    },
    {
      "id": "andhra_vizag",
      "name": "Vizag (Visakhapatnam)",
      "state": "Andhra Pradesh",
      "region_label": "Visakhapatnam",
      "latitude": 17.6868,
      "longitude": 83.2185,
      "description": "Port city known for Rushikonda and Ramakrishna beaches with strong waves.",
      "water_temp_c_min": 27, "water_temp_c_max": 30,
      "visibility_typical_m": 5, "avg_wave_height_m_typical": 1.2,
      "crowd_level": "very_high", "crowd_index": 8,
      "activities_available": ["surfing", "jet_skiing", "kayaking", "banana_boat"],
      "avg_daily_cost_inr": 4800,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "medium", "swell_typical_m": 1.1,
      "highlights": ["Visakhapatnam", "Andhra Pradesh"],
      "best_months": [10, 11, 12, 1, 2, 3]
    },
    {
      "id": "tamil_chennai_beaches",
      "name": "Chennai Beaches",
      "state": "Tamil Nadu",
      "region_label": "Chennai",
      "latitude": 12.9716,
      "longitude": 80.2532,
      "description": "Elliot's Beach and ECR beaches, hub of surfing in India.",
      "water_temp_c_min": 27, "water_temp_c_max": 30,
      "visibility_typical_m": 4, "avg_wave_height_m_typical": 1.0,
      "crowd_level": "high", "crowd_index": 8,
      "activities_available": ["surfing", "atv", "sup"],
      "avg_daily_cost_inr": 5000,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.9,
      "highlights": ["Chennai", "Tamil Nadu"],
      "best_months": [10, 11, 12, 1, 2]
    },
    {
      "id": "andaman_radhanagar",
      "name": "Radhanagar Beach",
      "state": "Andaman & Nicobar",
      "region_label": "Swaraj Dweep",
      "latitude": 11.9833,
      "longitude": 92.9500,
      "description": "One of Asia's best beaches, stunning sunsets and fine white sand.",
      "water_temp_c_min": 27, "water_temp_c_max": 30,
      "visibility_typical_m": 15, "avg_wave_height_m_typical": 0.8,
      "crowd_level": "high", "crowd_index": 7,
      "activities_available": ["scuba_diving", "snorkeling", "jet_skiing"],
      "avg_daily_cost_inr": 5500,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.7,
      "highlights": ["Swaraj Dweep", "Andaman"],
      "best_months": [10, 11, 12, 1, 2, 3, 4]
    },
    {
      "id": "kerala_marari",
      "name": "Marari Beach",
      "state": "Kerala",
      "region_label": "Alappuzha",
      "latitude": 9.5985,
      "longitude": 76.2974,
      "description": "Quiet beach near Alleppey backwaters, perfect for relaxation.",
      "water_temp_c_min": 27, "water_temp_c_max": 30,
      "visibility_typical_m": 5, "avg_wave_height_m_typical": 0.6,
      "crowd_level": "moderate", "crowd_index": 4,
      "activities_available": ["sup", "kayaking"],
      "avg_daily_cost_inr": 6000,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.5,
      "highlights": ["Alappuzha", "Kerala"],
      "best_months": [9, 10, 11, 12, 1, 2, 3]
    },
    {
      "id": "kerala_kappad",
      "name": "Kappad Beach",
      "state": "Kerala",
      "region_label": "Kozhikode",
      "latitude": 11.3856,
      "longitude": 75.7187,
      "description": "Historic beach where Vasco da Gama landed, serene and peaceful.",
      "water_temp_c_min": 27, "water_temp_c_max": 30,
      "visibility_typical_m": 4, "avg_wave_height_m_typical": 0.7,
      "crowd_level": "low", "crowd_index": 3,
      "activities_available": ["banana_boat"],
      "avg_daily_cost_inr": 4000,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.6,
      "highlights": ["Kozhikode", "Kerala"],
      "best_months": [10, 11, 12, 1, 2, 3]
    },
    {
      "id": "gujarat_dwarka",
      "name": "Dwarka Beach",
      "state": "Gujarat",
      "region_label": "Devbhumi Dwarka",
      "latitude": 22.2394,
      "longitude": 68.9676,
      "description": "Holy city beach with scuba diving opportunities to explore submerged ancient Dwarka.",
      "water_temp_c_min": 23, "water_temp_c_max": 28,
      "visibility_typical_m": 6, "avg_wave_height_m_typical": 0.8,
      "crowd_level": "high", "crowd_index": 8,
      "activities_available": ["scuba_diving", "snorkeling"],
      "avg_daily_cost_inr": 3500,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.7,
      "highlights": ["Devbhumi Dwarka", "Gujarat"],
      "best_months": [10, 11, 12, 1, 2, 3]
    },
    {
      "id": "gujarat_somnath",
      "name": "Somnath Beach",
      "state": "Gujarat",
      "region_label": "Gir Somnath",
      "latitude": 20.8880,
      "longitude": 70.4010,
      "description": "Pilgrim destination beach with sunset views and camel rides.",
      "water_temp_c_min": 24, "water_temp_c_max": 28,
      "visibility_typical_m": 3, "avg_wave_height_m_typical": 0.9,
      "crowd_level": "high", "crowd_index": 8,
      "activities_available": ["horse_riding"],
      "avg_daily_cost_inr": 3200,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "medium", "swell_typical_m": 0.8,
      "highlights": ["Gir Somnath", "Gujarat"],
      "best_months": [10, 11, 12, 1, 2, 3]
    },
    {
      "id": "maharashtra_ganpatipule",
      "name": "Ganpatipule",
      "state": "Maharashtra",
      "region_label": "Ratnagiri",
      "latitude": 17.1424,
      "longitude": 73.2687,
      "description": "Pristine white sand beach with a famous Ganesha temple.",
      "water_temp_c_min": 26, "water_temp_c_max": 29,
      "visibility_typical_m": 5, "avg_wave_height_m_typical": 0.7,
      "crowd_level": "high", "crowd_index": 7,
      "activities_available": ["parasailing", "banana_boat", "jet_skiing", "horse_riding"],
      "avg_daily_cost_inr": 4000,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.6,
      "highlights": ["Ratnagiri", "Maharashtra"],
      "best_months": [10, 11, 12, 1, 2]
    },
    {
      "id": "goa_vagator",
      "name": "Vagator Beach",
      "state": "Goa",
      "region_label": "North Goa",
      "latitude": 15.6030,
      "longitude": 73.7336,
      "description": "Dramatic red cliffs, famous for parties and sunset views.",
      "water_temp_c_min": 26, "water_temp_c_max": 30,
      "visibility_typical_m": 6, "avg_wave_height_m_typical": 0.6,
      "crowd_level": "high", "crowd_index": 8,
      "activities_available": ["parasailing", "jet_skiing", "atv"],
      "avg_daily_cost_inr": 5000,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.6,
      "highlights": ["North Goa", "Goa"],
      "best_months": [10, 11, 12, 1, 2, 3]
    },
    {
      "id": "odisha_konark",
      "name": "Chandrabhaga Beach",
      "state": "Odisha",
      "region_label": "Puri",
      "latitude": 19.8665,
      "longitude": 86.1158,
      "description": "Clean and environmentally certified beach near Konark Sun Temple.",
      "water_temp_c_min": 26, "water_temp_c_max": 29,
      "visibility_typical_m": 4, "avg_wave_height_m_typical": 1.2,
      "crowd_level": "moderate", "crowd_index": 6,
      "activities_available": ["surfing", "atv", "horse_riding"],
      "avg_daily_cost_inr": 3500,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "medium", "swell_typical_m": 1.1,
      "highlights": ["Puri", "Odisha"],
      "best_months": [10, 11, 12, 1, 2]
    },
    {
      "id": "west_bengal_mandarmani",
      "name": "Mandarmani",
      "state": "West Bengal",
      "region_label": "Purba Medinipur",
      "latitude": 21.6667,
      "longitude": 87.7000,
      "description": "Long drive-in beach popular with weekend tourists from Kolkata.",
      "water_temp_c_min": 25, "water_temp_c_max": 30,
      "visibility_typical_m": 3, "avg_wave_height_m_typical": 0.7,
      "crowd_level": "high", "crowd_index": 7,
      "activities_available": ["atv", "parasailing", "jet_skiing", "banana_boat"],
      "avg_daily_cost_inr": 4500,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.6,
      "highlights": ["Purba Medinipur", "West Bengal"],
      "best_months": [10, 11, 12, 1, 2, 3]
    },
    {
      "id": "west_bengal_bakkhali",
      "name": "Bakkhali",
      "state": "West Bengal",
      "region_label": "South 24 Parganas",
      "latitude": 21.5644,
      "longitude": 88.2618,
      "description": "Crescent shaped beach fringed by casuarina trees.",
      "water_temp_c_min": 25, "water_temp_c_max": 30,
      "visibility_typical_m": 3, "avg_wave_height_m_typical": 0.6,
      "crowd_level": "moderate", "crowd_index": 5,
      "activities_available": ["banana_boat"],
      "avg_daily_cost_inr": 3500,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.5,
      "highlights": ["South 24 Parganas", "West Bengal"],
      "best_months": [10, 11, 12, 1, 2]
    },
    {
      "id": "lakshadweep_kavaratti",
      "name": "Kavaratti",
      "state": "Lakshadweep",
      "region_label": "Lakshadweep",
      "latitude": 10.5667,
      "longitude": 72.6333,
      "description": "Capital of Lakshadweep, offering pristine lagoons and water sports.",
      "water_temp_c_min": 27, "water_temp_c_max": 30,
      "visibility_typical_m": 18, "avg_wave_height_m_typical": 0.5,
      "crowd_level": "low", "crowd_index": 3,
      "activities_available": ["scuba_diving", "snorkeling", "kayaking", "sup"],
      "avg_daily_cost_inr": 4500,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.4,
      "highlights": ["Lakshadweep"],
      "best_months": [10, 11, 12, 1, 2, 3, 4]
    },
    {
      "id": "lakshadweep_bangaram",
      "name": "Bangaram Island",
      "state": "Lakshadweep",
      "region_label": "Lakshadweep",
      "latitude": 10.9416,
      "longitude": 72.2882,
      "description": "Teardrop shaped uninhabited island known for bioluminescent beaches.",
      "water_temp_c_min": 27, "water_temp_c_max": 30,
      "visibility_typical_m": 25, "avg_wave_height_m_typical": 0.4,
      "crowd_level": "very_low", "crowd_index": 1,
      "activities_available": ["scuba_diving", "snorkeling", "kayaking", "island_hopping"],
      "avg_daily_cost_inr": 8000,
      "tide_profile": "moderate_semidiurnal", "weather_status": "tropical_coastal",
      "base_risk_level": "low", "swell_typical_m": 0.3,
      "highlights": ["Lakshadweep"],
      "best_months": [10, 11, 12, 1, 2, 3, 4]
    }
]

existing_dest_ids = {d["id"] for d in coastal_data["destinations"]}
for d in new_destinations:
    if d["id"] not in existing_dest_ids:
        coastal_data["destinations"].append(d)

with open(coastal_path, "w", encoding="utf-8") as f:
    json.dump(coastal_data, f, indent=2)

print("Added new activities and destinations.")
