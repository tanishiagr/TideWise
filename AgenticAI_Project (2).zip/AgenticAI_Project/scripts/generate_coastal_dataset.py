"""One-off generator for coastal_data.json — run: python scripts/generate_coastal_dataset.py"""
from __future__ import annotations

import json
from pathlib import Path

# Famous / touristy Indian coastal & island spots (approximate coords for mapping)
DESTS = [
    ("goa_calangute", "Calangute–Baga stretch", "Goa", "North Goa", 15.5385, 73.7553, "India's most visited beach belt: golden sand, wide shelf, strong tourism infrastructure, and quick access to scuba at Grande Island.", 26, 30, 7, 0.55, "very_high", 9),
    ("goa_palolem", "Palolem Beach", "Goa", "South Goa", 15.0097, 74.0233, "Crescent bay with calm lagoon-like sections; popular for kayaking, dolphin trips, and relaxed coastal stays.", 26, 30, 9, 0.45, "high", 8),
    ("goa_arambol", "Arambol Beach", "Goa", "North Goa", 15.6840, 73.7040, "Bohemian vibe, freshwater lake nearby; cliff viewpoints and beginner-friendly surf in season.", 26, 29, 8, 0.6, "high", 7),
    ("goa_grand_island", "Grande Island (boat hub)", "Goa", "Offshore", 15.1200, 73.4800, "Premier scuba and snorkel site accessed by short boat runs from Sinquerim–Coco Beach.", 26, 30, 10, 0.5, "moderate", 5),
    ("karnataka_gokarna", "Gokarna", "Karnataka", "Uttara Kannada", 14.5500, 74.3180, "Temple town with Om, Kudle, and Half Moon beaches; island views and surf-friendly swells in winter.", 27, 29, 7, 1.0, "high", 8),
    ("karnataka_malpe", "Malpe Beach", "Karnataka", "Udupi", 13.3490, 74.7040, "Gateway to St. Mary's Islands basalt columns; ferries and water sports hub.", 27, 29, 6, 0.7, "high", 8),
    ("karnataka_murudeshwar", "Murudeshwar", "Karnataka", "Uttara Kannada", 14.0941, 74.4855, "Iconic Shiva statue and scuba training with clear Arabian Sea waters offshore.", 27, 29, 8, 0.65, "moderate", 6),
    ("kerala_kovalam", "Kovalam", "Kerala", "Thiruvananthapuram", 8.4009, 76.9787, "Three-curve bay with lighthouse; calm swimming coves and strong Ayurveda tourism.", 27, 30, 6, 0.8, "very_high", 9),
    ("kerala_varkala", "Varkala Cliff Beach", "Kerala", "Thiruvananthapuram", 8.7378, 76.7164, "Mineral springs and dramatic laterite cliffs; surf schools and seasonal bigger swells.", 27, 30, 7, 0.85, "high", 8),
    ("kerala_alleppey_beach", "Alappuzha Beach", "Kerala", "Alappuzha", 9.4901, 76.3264, "Backwater–coast interface; houseboat circuits plus gentle beach recreation.", 27, 30, 5, 0.4, "high", 8),
    ("kerala_bekal", "Bekal Beach", "Kerala", "Kasaragod", 12.3927, 75.0322, "Historic fort backdrop; relatively quieter shoreline on the northern Kerala coast.", 27, 29, 7, 0.55, "moderate", 5),
    ("tamil_mahabalipuram", "Mahabalipuram", "Tamil Nadu", "Chengalpattu", 12.6208, 80.1945, "UNESCO shore temples; sandy bay with surf schools and strong cultural tourism.", 27, 30, 6, 0.75, "very_high", 9),
    ("tamil_marina", "Marina Beach (zone)", "Tamil Nadu", "Chennai", 13.0500, 80.2824, "Urban promenade; swimming not recommended — use for city-coastal context only.", 27, 30, 4, 0.6, "extreme", 10),
    ("tamil_rameswaram", "Rameswaram / Dhanushkodi", "Tamil Nadu", "Ramanathapuram", 9.2881, 79.3128, "Pilgrim island with long bridges; wind-swept ghost-town coast at Dhanushkodi.", 27, 30, 6, 0.9, "high", 8),
    ("tamil_kanyakumari", "Kanyakumari", "Tamil Nadu", "Kanyakumari", 8.0883, 77.5385, "Confluence of three seas; rocky shore, monument viewpoints, and ferry to Vivekananda Rock.", 27, 30, 8, 0.7, "very_high", 9),
    ("puducherry_promenade", "Rock Beach / Promenade", "Puducherry", "Puducherry", 11.9136, 79.8145, "French Quarter waterfront; volcanic dark sand stretches nearby toward Auroville coast.", 27, 30, 5, 0.5, "high", 8),
    ("andaman_port_blair", "Port Blair", "Andaman & Nicobar", "South Andaman", 11.6234, 92.7265, "Capital hub; Cellular Jail heritage, harbours, and ferry connections to Havelock & Neil.", 27, 30, 12, 0.6, "high", 8),
    ("andaman_havelock", "Havelock (Swaraj Dweep)", "Andaman & Nicobar", "Middle Andaman", 12.0345, 92.9990, "Radhanagar and Elephant Beach: coral reefs, scuba, and strong tidal planning needed.", 27, 30, 15, 0.95, "high", 8),
    ("andaman_neil", "Neil Island (Shaheed Dweep)", "Andaman & Nicobar", "Andaman", 11.8330, 93.0500, "Small-island cycling vibe; snorkel-friendly reefs and relaxed ferry hops.", 27, 30, 14, 0.7, "moderate", 6),
    ("lakshadweep_agatti", "Agatti Island", "Lakshadweep", "Lakshadweep", 10.8310, 72.1760, "Coral atoll lagoon; permits required — world-class visibility in calm windows.", 27, 30, 20, 0.4, "low", 4),
    ("maharashtra_mumbai_juhu", "Juhu–Versova coast", "Maharashtra", "Mumbai", 19.0880, 72.8260, "Metro beachfront; strong currents — water sports mainly at managed operators.", 25, 29, 4, 0.7, "extreme", 10),
    ("maharashtra_alibaug", "Alibaug & Kashid", "Maharashtra", "Raigad", 18.6414, 72.8682, "Weekend coast from Mumbai; Kashid crescent sand and speedboat links.", 26, 29, 6, 0.65, "very_high", 9),
    ("maharashtra_tarkarli", "Tarkarli–Devbagh", "Maharashtra", "Sindhudurg", 16.0390, 73.4890, "Clear Malvan water; Sindhudurg fort snorkel and scuba training sites.", 26, 29, 10, 0.5, "high", 7),
    ("maharashtra_ganpatipule", "Ganpatipule", "Maharashtra", "Ratnagiri", 17.1480, 73.2720, "Red-cliff temple beach; gentler waves suitable for families in season.", 26, 29, 8, 0.55, "moderate", 6),
    ("gujarat_diu", "Diu", "Dadra and Nagar Haveli and Daman and Diu", "Diu", 20.7144, 70.9874, "Portuguese fort town; Nagoa bay water sports and lower monsoon intensity than Konkan.", 25, 29, 7, 0.45, "high", 7),
    ("gujarat_mandvi", "Mandvi Beach", "Gujarat", "Kutch", 22.8380, 69.3600, "Arabian Sea wind flats; Vijay Vilas Palace backdrop and seasonal kite tourism.", 24, 29, 5, 0.4, "moderate", 6),
    ("odisha_puri", "Puri Beach", "Odisha", "Puri", 19.7983, 85.8240, "Pilgrim city beach; long swells in monsoon; cultural tourism dominates.", 27, 30, 5, 0.9, "very_high", 9),
    ("odisha_chandipur", "Chandipur", "Odisha", "Balasore", 21.4590, 87.0850, "Unique receding tide flats; educational coastline rather than heavy water sports.", 26, 30, 4, 0.35, "moderate", 5),
    ("westbengal_digha", "Digha", "West Bengal", "Purba Medinipur", 21.6266, 87.5080, "Popular flat beach; gentle shelf — jet skis and local vendors cluster in peak season.", 26, 29, 4, 0.45, "very_high", 9),
    ("westbengal_mandarmani", "Mandarmani", "West Bengal", "Purba Medinipur", 21.6557, 87.7060, "Motorable beach strip; resort-driven water activities.", 26, 29, 4, 0.5, "high", 8),
    ("andhra_rushikonda", "Rushikonda Beach", "Andhra Pradesh", "Visakhapatnam", 17.7822, 83.3850, "Bay of Bengal surf and kayak launches near Vizag hills.", 27, 30, 6, 0.85, "high", 8),
    ("andhra_vizag_ramakrishna", "RK Beach corridor", "Andhra Pradesh", "Visakhapatnam", 17.7142, 83.3235, "Urban submarines museum strip; managed coastal recreation.", 27, 30, 5, 0.6, "very_high", 9),
    ("damandiu_daman", "Devka–Jampore (Daman)", "Dadra and Nagar Haveli and Daman and Diu", "Daman", 20.4280, 72.8390, "Quieter than Goa peak pockets; black-sand stretches and resort water sports.", 26, 30, 5, 0.5, "moderate", 6),
]

ACTIVITIES_FULL = ["scuba_diving", "snorkeling", "surfing", "kayaking", "island_hopping"]
ACTIVITIES_NO_SURF = ["scuba_diving", "snorkeling", "kayaking", "island_hopping"]
ACTIVITIES_SHORE = ["kayaking", "snorkeling"]


def acts_for(row):
    name = row[1].lower()
    if "marina" in name or "mumbai_juhu" in row[0]:
        return ["kayaking"]
    if "chandipur" in row[0] or "mandvi" in row[0]:
        return ["kayaking", "snorkeling"]
    if "kanyakumari" in row[0] or "rameswaram" in row[0]:
        return ACTIVITIES_NO_SURF
    if "lakshadweep" in row[0] or "andaman" in row[0] or "tarkarli" in row[0] or "goa_grand" in row[0]:
        return ACTIVITIES_FULL
    if "gokarna" in row[0] or "mahabalipuram" in row[0] or "rushikonda" in row[0]:
        return ACTIVITIES_FULL
    return ACTIVITIES_NO_SURF


def main():
    out = []
    for row in DESTS:
        tid, name, state, region, lat, lon, desc, wt_lo, wt_hi, vis, wave, crowd, cidx = row
        out.append(
            {
                "id": tid,
                "name": name,
                "state": state,
                "region_label": region,
                "latitude": lat,
                "longitude": lon,
                "description": desc,
                "water_temp_c_min": wt_lo,
                "water_temp_c_max": wt_hi,
                "visibility_typical_m": vis,
                "avg_wave_height_m_typical": wave,
                "crowd_level": crowd,
                "crowd_index": cidx,
                "activities_available": acts_for(row),
                "avg_daily_cost_inr": 3200 + (cidx * 180),
                "tide_profile": "moderate_semidiurnal",
                "weather_status": "tropical_coastal",
                "base_risk_level": "medium" if wave > 0.85 else "low",
                "swell_typical_m": round(wave * 1.05, 2),
                "highlights": [region, state],
                "best_months": [10, 11, 12, 1, 2, 3, 4],
            }
        )
    path = Path(__file__).resolve().parent.parent / "tidewise" / "data" / "coastal_data.json"
    path.write_text(json.dumps({"schema_version": "2.0", "destinations": out}, indent=2), encoding="utf-8")
    print("Wrote", path, "count", len(out))


if __name__ == "__main__":
    main()
