"""
Assembles traveler-facing `trip` payload vs academic `technical_details`.

Integrates Open-Meteo, Nominatim, sklearn activity ranker, and local JSON corpora.
"""

from __future__ import annotations

from typing import Any

from tidewise.ml.preference_ranker import ActivityPreferenceRanker
from tidewise.rag_store import CoastalRAGStore
from tidewise.services.forecast import fetch_trip_forecast_bundle
from tidewise.services.geocode import reverse_geocode

_RANKER: ActivityPreferenceRanker | None = None


def _ranker() -> ActivityPreferenceRanker:
    global _RANKER
    if _RANKER is None:
        _RANKER = ActivityPreferenceRanker()
    return _RANKER


def enrich_for_client(
    raw: dict[str, Any],
    live_steps: list[str],
    rag: CoastalRAGStore,
) -> dict[str, Any]:
    dest = raw["recommendation"]["top_pick"]
    prefs = raw["parsed_preferences"]
    budget = raw["budget"]
    safety = raw["safety"]
    logistics = raw["marine_logistics"]
    bookings = raw["bookings"]
    itinerary = raw["itinerary"]
    adaptation = raw["adaptation"]
    ranker = _ranker()

    lat = float(dest["latitude"])
    lon = float(dest["longitude"])
    days = int(prefs.get("duration_days", 4))

    forecast = fetch_trip_forecast_bundle(lat, lon, days)
    rev = None
    try:
        rev = reverse_geocode(lat, lon)
    except Exception:
        rev = None

    wave_typical = float(dest.get("avg_wave_height_m_typical", dest.get("swell_typical_m", 0.7)))
    vis_typical = float(dest.get("visibility_typical_m", 8))

    # Optional: refine averages from live forecast first day
    api_wave_avg = None
    api_vis_avg = None
    if forecast.get("ok") and forecast.get("days"):
        hrs = forecast["days"][0].get("hours") or []
        if hrs:
            api_wave_avg = round(sum(h["wave_height_m"] for h in hrs) / len(hrs), 2)
            vis_vals = [h["visibility_m"] for h in hrs if h.get("visibility_m")]
            if vis_vals:
                api_vis_avg = round(sum(vis_vals) / len(vis_vals), 0)

    activity_rows: list[dict[str, Any]] = []
    for act in safety.get("safe_activities", []):
        meta = rag.activity_by_id(act["id"])
        exp_w = float(meta.get("experience_weight", 5)) if meta else 5.0
        act_risk = int(act.get("risk_score", 2))
        ml = ranker.score_activity(
            budget_inr=float(prefs.get("budget_inr") or 35_000),
            user_max_risk=int(prefs.get("max_activity_risk_score", 3)),
            activity_risk=act_risk,
            experience_weight=exp_w,
            typical_wave_m=wave_typical,
        )
        bmatch = next(
            (b for b in bookings.get("booking_options", []) if b.get("activity_id") == act["id"]),
            None,
        )
        activity_rows.append(
            {
                "id": act["id"],
                "name": act["display_name"],
                "risk_tier": act_risk,
                "safety_score": act.get("safety_score"),
                "typical_cost_inr": meta.get("typical_cost_inr") if meta else None,
                "ml_preference_fit_score": round(ml, 4),
                "ml_model": "sklearn.ensemble.GradientBoostingRegressor (synthetic training)",
                "booking_slot": bmatch.get("slot") if bmatch else None,
                "booking_available": bmatch.get("available") if bmatch else None,
                "estimated_booking_inr": bmatch.get("estimated_cost_inr") if bmatch else None,
            }
        )
    activity_rows.sort(key=lambda x: x["ml_preference_fit_score"], reverse=True)

    osm_link = f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=13/{lat}/{lon}"

    destination_overview = {
        "title": dest["name"],
        "region": dest.get("region_label"),
        "state": dest["state"],
        "coordinates": {"latitude": lat, "longitude": lon},
        "nominatim_display_name": rev.get("display_name") if rev else None,
        "description": dest.get("description", ""),
        "water_temperature_c": {
            "typical_min": dest.get("water_temp_c_min"),
            "typical_max": dest.get("water_temp_c_max"),
            "note": "Seasonal range; sea_surface_temp in hourly forecast when API succeeds.",
        },
        "visibility_m": {
            "dataset_typical": vis_typical,
            "forecast_day1_avg_m": api_vis_avg,
        },
        "waves_m": {
            "dataset_typical_avg_height": wave_typical,
            "forecast_day1_avg_height": api_wave_avg,
        },
        "crowd": {
            "level": dest.get("crowd_level"),
            "index_1_to_10": dest.get("crowd_index"),
        },
        "adventure_options": [
            {"id": a, "label": (rag.activity_by_id(a) or {}).get("display_name", a)}
            for a in dest.get("activities_available", [])
        ],
        "openstreetmap_url": osm_link,
        "map": {"provider": "OpenStreetMap tiles (Leaflet)", "center_lat": lat, "center_lon": lon, "zoom": 12},
    }

    # Marine forecast section: hourly + narrative
    caution_hours = 0
    if forecast.get("days"):
        for d in forecast["days"]:
            for h in d.get("hours", []):
                if h.get("marine_suitability") != "good":
                    caution_hours += 1

    safe_marine_forecast = {
        "forecast_bundle": forecast,
        "risk_label": safety.get("risk_label"),
        "overall_safety_score": safety.get("overall_safety_score"),
        "blocked_activities": safety.get("blocked_activities", []),
        "rules_engine": "Symbolic filters from activity_data.json + live hourly marine/weather",
        "trip_hour_statistics": {
            "hours_with_non_good_marine": caution_hours,
            "interpretation": "Higher counts suggest more windows where operators may delay in-water blocks.",
        },
    }

    logistics_and_budget = {
        "marine_logistics": logistics,
        "budget": budget,
        "cost_breakdown_inr": budget.get("breakdown"),
        "utility_score": budget.get("utility_score"),
        "reward_signal": budget.get("reward_signal"),
        "within_budget": budget.get("within_budget"),
    }

    operators = rag.operators_for_destination(dest["id"])
    equipment_and_operators = {
        "local_operators": operators,
        "recommended_equipment": [
            "ISO-certified life jacket for offshore legs",
            "Reef-safe sunscreen SPF 50+",
            "Dry bag for electronics",
            "Water shoes / booties on rocky shores",
            "First-aid kit + motion sickness meds for ferries",
        ],
        "certification_reminder": "Confirm PADI/SSI/RLS for scuba; ISA-affiliated schools for surf.",
    }

    adaptive_itinerary = {
        "days_after_adaptation": adaptation.get("itinerary_after", itinerary.get("days")),
        "days_before_adaptation": adaptation.get("itinerary_before"),
        "simulated_disruption": adaptation.get("simulated_event"),
        "adaptation_notes": adaptation.get("adaptation_notes", []),
        "adaptive_planning_rules": itinerary.get("adaptive_planning_rules", []),
        "packing_notes": itinerary.get("packing_notes", []),
    }

    emergency = rag.emergency_for_destination(dest["id"])
    emergency_services = {
        **emergency,
        "destination_context": dest["name"],
        "disclaimer": "Verify phone numbers locally; this demo uses placeholders + public service codes.",
    }

    breakdown = budget.get("breakdown", {})
    expense_breakdown_str = f"Expense Breakdown (for {prefs.get('group_size', 2)} traveller(s)): Accommodation ₹{breakdown.get('accommodation_inr', 0):,}, Food & Misc ₹{breakdown.get('food_misc_inr', 0):,}, Activities ₹{breakdown.get('activities_inr', 0):,}, Transfers ₹{breakdown.get('marine_transfer_inr', 0):,}"

    apis_used = ["Open-Meteo Marine", "Open-Meteo Weather", "OpenStreetMap Nominatim"]
    trip_intelligence_summary = {
        "headline": f"Optimized coastal plan for {dest['name']} ({dest['state']})",
        "bullets": [
            f"Utility {budget.get('utility_score')} | simulated reward {budget.get('reward_signal')} | risk band {safety.get('risk_label')}",
            f"Estimated spend ₹{budget.get('estimated_total_inr', 0):,} vs budget {prefs.get('budget_inr') or 'flexible'}",
            expense_breakdown_str,
            f"Live forecast ingested: {'yes' if forecast.get('ok') else 'fallback mode'}",
            f"ML re-ranking applied to {len(activity_rows)} safe activities (GradientBoostingRegressor)",
            f"Logistics feasibility flag: {logistics.get('feasible')}",
        ],
        "data_sources": apis_used + ["coastal_data.json", "logistics_data.json", "activity_data.json", "emergency_data.json", "operators_data.json"],
    }

    technical_details = {
        "execution_pipeline_ascii": """
User Interaction → Coastal Research (RAG) → Marine Logistics → Safety Evaluation
→ Adventure Booking → Budget Optimization → Recommendation → Itinerary
→ Real-Time Adaptation
        """.strip(),
        "specialized_agents": [
            "UserInteractionAgent",
            "CoastalResearchAgent",
            "MarineLogisticsAgent",
            "SafetyEvaluationAgent",
            "AdventureBookingAgent",
            "BudgetOptimizationAgent",
            "RecommendationAgent",
            "ItineraryAgent",
            "RealTimeAdaptationAgent",
            "CoordinatorAgent",
        ],
        "live_agent_trace": live_steps,
        "simulated_llm_style_synthesis": raw.get("llm_style_summary"),
        "learning_snapshot": raw.get("learning"),
        "syllabus_alignment": raw.get("syllabus_map"),
        "parsed_preferences_debug": prefs,
    }

    return {
        "trip": {
            "destination_overview": destination_overview,
            "safe_marine_forecast": safe_marine_forecast,
            "recommended_activities": activity_rows,
            "logistics_and_budget": logistics_and_budget,
            "equipment_and_operators": equipment_and_operators,
            "adaptive_itinerary": adaptive_itinerary,
            "emergency_services": emergency_services,
            "trip_intelligence_summary": trip_intelligence_summary,
        },
        "technical_details": technical_details,
    }
