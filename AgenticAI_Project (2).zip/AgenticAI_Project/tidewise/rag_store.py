"""
RAG-style retrieval over local JSON corpora (no external vector DB).

Chunks are built from structured records; retrieval uses token overlap scoring
plus optional filters — simulates embedding retrieval for coursework demos.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterable


@dataclass
class RetrievalHit:
    source: str
    chunk_id: str
    text: str
    score: float
    payload: dict[str, Any]


def _tokenize(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9_]+", text.lower()))


def _score(query_tokens: set[str], doc_tokens: set[str]) -> float:
    if not query_tokens or not doc_tokens:
        return 0.0
    inter = len(query_tokens & doc_tokens)
    return inter / (len(query_tokens) ** 0.5 * len(doc_tokens) ** 0.5 + 1e-9)


class CoastalRAGStore:
    """Loads coastal, logistics, and activity JSON and serves retrieval queries."""

    def __init__(self, data_dir: Path | None = None) -> None:
        base = data_dir or Path(__file__).resolve().parent / "data"
        self._coastal = self._load_json(base / "coastal_data.json")
        self._logistics = self._load_json(base / "logistics_data.json")
        self._activity = self._load_json(base / "activity_data.json")
        self._emergency = self._load_json_optional(base / "emergency_data.json")
        self._operators = self._load_json_optional(base / "operators_data.json")
        self._chunks: list[tuple[str, str, str, dict[str, Any]]] = []
        self._index()

    @staticmethod
    def _load_json(path: Path) -> dict[str, Any]:
        with path.open(encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def _load_json_optional(path: Path) -> dict[str, Any]:
        if not path.is_file():
            return {}
        with path.open(encoding="utf-8") as f:
            return json.load(f)

    def _index(self) -> None:
        for d in self._coastal.get("destinations", []):
            text = " ".join(
                [
                    d.get("name", ""),
                    d.get("state", ""),
                    d.get("description", ""),
                    d.get("region_label", ""),
                    " ".join(d.get("activities_available", [])),
                    d.get("tide_profile", ""),
                    d.get("weather_status", ""),
                    d.get("base_risk_level", ""),
                    " ".join(d.get("highlights", [])),
                ]
            )
            self._chunks.append(("coastal_data.json", d["id"], text, d))

        for e in self._logistics.get("edges", []):
            text = f"{e['from']} {e['to']} {e['mode']} {e.get('notes', '')}"
            cid = f"edge:{e['from']}->{e['to']}"
            self._chunks.append(("logistics_data.json", cid, text, e))

        for n in self._logistics.get("nodes", []):
            text = f"{n['id']} {n.get('label', '')} {n.get('type', '')}"
            self._chunks.append(("logistics_data.json", f"node:{n['id']}", text, n))

        for a in self._activity.get("activities", []):
            text = " ".join(
                [
                    a.get("display_name", ""),
                    a.get("id", ""),
                    " ".join(a.get("symbolic_rules", [])),
                ]
            )
            self._chunks.append(("activity_data.json", a["id"], text, a))

    def retrieve(
        self,
        query: str,
        *,
        source_filter: str | None = None,
        top_k: int = 8,
        payload_filter: Callable[[dict[str, Any]], bool] | None = None,
    ) -> list[RetrievalHit]:
        q_tokens = _tokenize(query)
        scored: list[tuple[float, tuple[str, str, str, dict[str, Any]]]] = []
        for source, cid, text, payload in self._chunks:
            if source_filter and source_filter not in source:
                continue
            if payload_filter and not payload_filter(payload):
                continue
            s = _score(q_tokens, _tokenize(text))
            if s > 0:
                scored.append((s, (source, cid, text, payload)))
        scored.sort(key=lambda x: x[0], reverse=True)
        out: list[RetrievalHit] = []
        for s, (source, cid, text, payload) in scored[:top_k]:
            out.append(
                RetrievalHit(
                    source=source,
                    chunk_id=cid,
                    text=text[:500],
                    score=round(s, 4),
                    payload=payload,
                )
            )
        return out

    def get_destination_by_id(self, dest_id: str) -> dict[str, Any] | None:
        for d in self._coastal.get("destinations", []):
            if d["id"] == dest_id:
                return d
        return None

    def all_destinations(self) -> list[dict[str, Any]]:
        return list(self._coastal.get("destinations", []))

    def activity_by_id(self, act_id: str) -> dict[str, Any] | None:
        for a in self._activity.get("activities", []):
            if a["id"] == act_id:
                return a
        return None

    def logistics_graph(self) -> dict[str, Any]:
        return self._logistics

    def emergency_for_destination(self, dest_id: str) -> dict[str, Any]:
        return dict(self._emergency.get("by_destination_id", {}).get(dest_id, {}))

    def operators_for_destination(self, dest_id: str) -> list[dict[str, Any]]:
        return list(self._operators.get("by_destination_id", {}).get(dest_id, []))
