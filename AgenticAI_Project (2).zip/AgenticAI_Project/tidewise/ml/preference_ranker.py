"""
GradientBoostingRegressor trained on synthetic preference data.

Features: budget INR, user max risk cap, activity risk, experience weight, local wave height.
Output: scalar "fit score" for ranking activities (not a production recommender).
"""

from __future__ import annotations

import numpy as np
from sklearn.ensemble import GradientBoostingRegressor


class ActivityPreferenceRanker:
    def __init__(self) -> None:
        rng = np.random.RandomState(42)
        n = 600
        budget = rng.uniform(8_000, 120_000, n)
        user_risk_cap = rng.randint(2, 6, n)
        act_risk = rng.randint(1, 6, n)
        experience_w = rng.uniform(3, 10, n)
        wave = rng.uniform(0.2, 2.2, n)
        X = np.column_stack([budget, user_risk_cap, act_risk, experience_w, wave])
        risk_pen = np.maximum(0, act_risk - user_risk_cap)
        y = (
            0.22 * np.log1p(budget) / np.log(120_000)
            + 0.28 * (user_risk_cap / 5)
            + 0.25 * (experience_w / 10)
            - 0.35 * risk_pen
            - 0.15 * np.clip(wave - 0.8, 0, 2)
            + rng.normal(0, 0.04, n)
        )
        self._model = GradientBoostingRegressor(
            random_state=42,
            max_depth=3,
            n_estimators=80,
            learning_rate=0.08,
        )
        self._model.fit(X, y)

    def score_activity(
        self,
        *,
        budget_inr: float | None,
        user_max_risk: int,
        activity_risk: int,
        experience_weight: float,
        typical_wave_m: float,
    ) -> float:
        b = float(budget_inr or 35_000)
        x = np.array([[b, user_max_risk, activity_risk, experience_weight, typical_wave_m]])
        return float(self._model.predict(x)[0])
