"""
FastAPI application — serves the static web UI and /api/plan for demos.

Run from repo root:
  pip install -r requirements.txt
  uvicorn tidewise.app:app --reload --host 127.0.0.1 --port 8000
"""

from __future__ import annotations

from pathlib import Path
import os
from dotenv import load_dotenv

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from tidewise.coordinator import CoordinatorAgent
from tidewise.rag_store import CoastalRAGStore
from tidewise.trip_enrichment import enrich_for_client

ROOT = Path(__file__).resolve().parent.parent
STATIC = ROOT / "static"

load_dotenv(ROOT / ".env")

app = FastAPI(
    title="Coastal Adventure Tourism — Multi-Agent System",
    description="Agentic AI demo for Indian coastal adventure planning (local JSON RAG, no paid APIs).",
    version="0.7.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_rag = CoastalRAGStore(Path(__file__).resolve().parent / "data")


class PlanRequest(BaseModel):
    query: str = Field(..., min_length=3, description="Natural language trip request")


@app.post("/api/plan")
def api_plan(body: PlanRequest) -> dict:
    coord = CoordinatorAgent(rag=_rag)
    result = coord.run(body.query)
    if result.get("error"):
        return result
    return enrich_for_client(result, list(result.get("steps", [])), _rag)


class BookingRequest(BaseModel):
    email: str
    activity: str
    vendor: str
    price: str
    phone: str | None = None
    date: str | None = None
    people: int | None = 1
    location: str | None = None

@app.post("/api/book")
def api_book(body: BookingRequest) -> dict:
    import smtplib
    import os
    from email.message import EmailMessage
    
    phone_info = f"\nPhone Number: {body.phone}" if body.phone else ""
    msg = EmailMessage()
    msg.set_content(f"Dear Traveler,\n\nYour adventure booking for {body.activity} with {body.vendor} is confirmed.\nTotal Price: {body.price}{phone_info}\n\nThank you for using TideWise! Get ready for your coastal adventure.")
    msg["Subject"] = f"Booking Confirmation: {body.activity}"
    msg["From"] = os.getenv("SMTP_USER", "bookings@tidewise.local")
    msg["To"] = body.email

    smtp_host = os.getenv("SMTP_HOST")
    smtp_port = os.getenv("SMTP_PORT", 587)
    smtp_user = os.getenv("SMTP_USER")
    smtp_pass = os.getenv("SMTP_PASS")

    if smtp_host and smtp_user and smtp_pass:
        try:
            with smtplib.SMTP(smtp_host, int(smtp_port)) as server:
                server.starttls()
                server.login(smtp_user, smtp_pass)
                server.send_message(msg)
            
            return {
                "status": "success", 
                "message": f"Real confirmation email successfully sent to {body.email}"
            }
        except Exception as e:
            print(f"Failed to send email via SMTP: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to send confirmation email. Check SMTP settings. Error: {e}")
    else:
        # Graceful fallback logic for simulated production
        import time
        ticket_id = f"TKT-{int(time.time())}"
        html_content = f"""
        <html><head><style>
          body {{ font-family: sans-serif; padding: 40px; background: #f0f7f9; }}
          .ticket {{ background: white; padding: 30px; border-radius: 8px; max-width: 600px; margin: 0 auto; box-shadow: 0 4px 15px rgba(0,0,0,0.1); border-top: 5px solid #2a7a8c; }}
          .header {{ display: flex; justify-content: space-between; border-bottom: 2px solid #eee; padding-bottom: 15px; margin-bottom: 20px; }}
          h2 {{ margin: 0; color: #154556; }}
          table {{ width: 100%; border-collapse: collapse; }}
          td {{ padding: 10px 0; border-bottom: 1px solid #eee; }}
          .footer {{ text-align: center; margin-top: 30px; font-size: 0.9em; color: #777; }}
        </style></head>
        <body>
          <div class="ticket">
            <div class="header">
              <h2>TideWise Booking Confirmation</h2>
              <span style="font-weight:bold; color:#e0845a">{ticket_id}</span>
            </div>
            <p>Dear Traveler,</p>
            <p>Your adventure is successfully booked. Show this ticket at the venue on your selected date.</p>
            <table>
              <tr><td><strong>Activity</strong></td><td>{body.activity}</td></tr>
              <tr><td><strong>Vendor</strong></td><td>{body.vendor}</td></tr>
              <tr><td><strong>Registered Email</strong></td><td>{body.email}</td></tr>
              <tr><td><strong>Total Paid</strong></td><td><strong style="color:#2a7a8c;font-size:1.1em">{body.price}</strong></td></tr>
              <tr><td><strong>Status</strong></td><td><span style="color:green;font-weight:bold">Confirmed</span></td></tr>
            </table>
            <div class="footer">
              <p>Sent via TideWise automated confirmed booking engine.<br>Get ready for your coastal adventure!</p>
            </div>
          </div>
        </body></html>
        """
        try:
            ticket_path = STATIC / "ticket.html"
            ticket_path.write_text(html_content, encoding="utf-8")
        except Exception as e:
            print(f"Failed to write mock ticket: {e}")

    return {
        "status": "success", 
        "message": f"Confirmation email sent to {body.email}",
        "ticket_url": "/assets/ticket.html?t=" + str(time.time())
    }


@app.post("/api/book/{service_type}")
def api_book_service(service_type: str, body: BookingRequest) -> dict:
    valid_services = {"flight", "hotel", "bus", "cruise", "cab", "tours", "villas"}
    if service_type not in valid_services:
        raise HTTPException(status_code=400, detail="Invalid service type")
    
    # Mock structured JSON response for the service booking
    import time
    ticket_id = f"{service_type.upper()}-{int(time.time())}"
    
    return {
        "status": "success",
        "service": service_type,
        "booking_id": ticket_id,
        "details": {
            "email": body.email,
            "phone": body.phone,
            "provider": body.vendor,
            "item": body.activity,
            "price": body.price,
            "date": body.date,
            "location": body.location,
            "people": body.people
        },
        "message": f"Successfully booked {service_type} with {body.vendor}."
    }

class BudgetRequest(BaseModel):
    total_budget: float
    duration_days: int
    group_size: int

@app.post("/api/budget/breakdown")
def calculate_budget_breakdown(body: BudgetRequest) -> dict:
    total = body.total_budget
    # Dynamic logic for distribution
    # accommodation: 35%, food: 25%, travel: 20%, activities: 15%, misc: 5%
    return {
        "total_estimated": total,
        "categories": {
            "Accommodation": {"percentage": 35, "amount": int(total * 0.35)},
            "Food": {"percentage": 25, "amount": int(total * 0.25)},
            "Travel": {"percentage": 20, "amount": int(total * 0.20)},
            "Activities": {"percentage": 15, "amount": int(total * 0.15)},
            "Miscellaneous": {"percentage": 5, "amount": int(total * 0.05)}
        }
    }

class ModifyPlanRequest(BaseModel):
    query: str
    original_plan_details: dict | None = None
    changes: dict # e.g. {"budget": 50000, "dates": "2026-06-01 to 2026-06-05", "add_activities": ["horse_riding"]}

@app.post("/api/plan/modify")
def modify_plan(body: ModifyPlanRequest) -> dict:
    # Use coordinator to re-run pipeline with modified context
    # This integrates Adaptive Planning Agent logic
    coord = CoordinatorAgent(rag=_rag)
    
    # We alter the query conceptually to help NLP parse it easily
    modified_query = body.query
    if body.changes.get("budget"):
        modified_query += f". Update budget to Rs. {body.changes['budget']}"
    if body.changes.get("add_activities"):
        acts_str = ", ".join(body.changes["add_activities"])
        modified_query += f". Add activities: {acts_str}"
        
    result = coord.run(modified_query)
    
    if result.get("error"):
        return result
        
    return enrich_for_client(result, list(result.get("steps", [])), _rag)

@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "destinations": len(_rag.all_destinations())}


if STATIC.is_dir():
    app.mount("/assets", StaticFiles(directory=STATIC), name="assets")


@app.get("/")
def index() -> FileResponse:
    index_path = STATIC / "index.html"
    if not index_path.is_file():
        raise HTTPException(
            status_code=500,
            detail="static/index.html missing — add the frontend bundle.",
        )
    return FileResponse(index_path)
