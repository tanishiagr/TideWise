"""
Coordinator Agent — central orchestrator for the multi-agent pipeline.

Pipeline (industry-style DAG):
  User Interaction → Coastal Research → Marine Logistics → Safety Evaluation
  → Adventure Booking → Budget Optimization → Recommendation → Itinerary
  → Real-Time Adaptation (simulated disruption)

Scaling note: In production this would be a message bus (Redis/Kafka) or
orchestration layer (Temporal); here we use direct calls + an explicit step log
for explainability and coursework demos.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from tidewise.agents.adventure_booking_agent import AdventureBookingAgent
from tidewise.agents.budget_optimization_agent import BudgetOptimizationAgent
from tidewise.agents.coastal_research_agent import CoastalResearchAgent
from tidewise.agents.itinerary_agent import ItineraryAgent
from tidewise.agents.marine_logistics_agent import MarineLogisticsAgent
from tidewise.agents.recommendation_agent import RecommendationAgent
from tidewise.agents.real_time_adaptation_agent import RealTimeAdaptationAgent
from tidewise.agents.safety_evaluation_agent import SafetyEvaluationAgent
from tidewise.agents.user_interaction_agent import UserInteractionAgent
from tidewise.rag_store import CoastalRAGStore

# Simulated session memory for adaptive behavior (feedback loop demo)
_LEARNING_STATE: dict[str, Any] = {"plans_generated": 0, "cumulative_reward": 0.0}


@dataclass
class CoordinatorAgent:
    rag: CoastalRAGStore = field(default_factory=CoastalRAGStore)
    on_step: Callable[[str], None] = field(default_factory=lambda: lambda _m: None)

    def __post_init__(self) -> None:
        self._ui = UserInteractionAgent()
        self._research = CoastalResearchAgent(self.rag)
        self._logistics = MarineLogisticsAgent(self.rag)
        self._safety = SafetyEvaluationAgent(self.rag)
        self._booking = AdventureBookingAgent(self.rag)
        self._budget = BudgetOptimizationAgent(self.rag)
        self._recommend = RecommendationAgent()
        self._itinerary = ItineraryAgent()
        self._adapt = RealTimeAdaptationAgent()

    def _log(self, msg: str) -> None:
        self.on_step(msg)

    def run(self, user_text: str) -> dict[str, Any]:
        steps: list[str] = []

        def log(msg: str) -> None:
            steps.append(msg)
            self._log(msg)

        log("Coordinator: pipeline start — decomposing user goal (best coastal adventure plan).")

        # 1) User Interaction
        log("User Interaction Agent: parsing preferences (budget, dates, activities, risk).")
        parsed = self._ui.process(user_text)
        if not parsed.get("success"):
            return {"error": True, "message": "Could not parse input", "steps": steps}
        prefs = parsed["parsed_preferences"]

        # 2) Research (RAG)
        log("Coastal Research Agent: retrieving destinations from coastal_data.json (RAG-style).")
        research = self._research.research(prefs)

        # Resolve destination: hint wins if valid, else research primary
        dest = research["primary_destination"]
        if prefs.get("destination_id_hint"):
            hinted = self.rag.get_destination_by_id(prefs["destination_id_hint"])
            if hinted:
                dest = hinted
                log(f"Coordinator: user hint locked destination → {dest['name']}.")

        # Activity candidate list: intersection of user prefs and destination offer
        dest_acts = set(dest.get("activities_available", []))
        user_acts = prefs.get("preferred_activity_ids") or []
        chosen = [a for a in user_acts if a in dest_acts]
        if not chosen:
            chosen = list(dest_acts)[:3]
            log("Coordinator: broadened activity set to destination defaults (no explicit match).")

        # 3) Marine Logistics
        log("Marine Logistics Agent: validating ferry/boat graph (logistics_data.json).")
        logistics = self._logistics.plan(dest, chosen)

        # Baseline marine state from dataset (refined by live APIs in trip_enrichment)
        weather = {
            "visibility_m": float(dest.get("visibility_typical_m", 8)),
            "wave_height_m": float(
                dest.get("avg_wave_height_m_typical", dest.get("swell_typical_m", 0.7))
            ),
            "wind_knots": 14,
            "tide_strength": "moderate",
        }

        # 4) Safety
        log("Safety Evaluation Agent: applying symbolic rules from activity_data.json + marine state.")
        safety = self._safety.evaluate(dest, chosen, weather, prefs)

        if not safety["safe_activities"]:
            log("Safety Agent: zero safe activities under current sim weather — retrying with calmer scenario.")
            calm = {**weather, "wave_height_m": 0.4, "wind_knots": 8, "visibility_m": 12.0}
            safety = self._safety.evaluate(dest, chosen, calm, prefs)
            weather = calm

        safe_ids = [a["id"] for a in safety["safe_activities"]]
        if not safe_ids:
            safe_ids = ["kayaking"] if "kayaking" in dest_acts else list(dest_acts)[:1]
            log("Coordinator: minimal fallback activity list for demo continuity (shore-only).")
            safety["safe_activities"] = []
            for sid in safe_ids:
                meta = self.rag.activity_by_id(sid)
                if meta:
                    safety["safe_activities"].append(
                        {
                            "id": sid,
                            "display_name": meta["display_name"],
                            "risk_score": meta["risk_score"],
                            "safety_score": 6.0,
                            "symbolic_rules_considered": meta.get("symbolic_rules", []),
                        }
                    )

        # 5) Booking simulation
        log("Adventure Booking Agent: simulating slots, pricing, availability.")
        bookings = self._booking.simulate_bookings(dest, safety["safe_activities"] or [{"id": safe_ids[0], "display_name": safe_ids[0]}], prefs["group_size"])

        # 6) Budget / utility / reward
        log("Budget Optimization Agent: utility = experience + safety - cost_penalty; reward signal computed.")
        budget = self._budget.optimize(
            prefs,
            dest,
            safety["safe_activities"],
            bookings["booking_options"],
            logistics,
        )

        # 7) Recommendations
        log("Recommendation Agent: fusing retrieval, utility, and safety narratives.")
        recommendation = self._recommend.recommend(research, budget, safety)

        # 8) Itinerary
        log("Itinerary Agent: assembling goal-oriented day-wise plan.")
        itinerary = self._itinerary.build(prefs, dest, bookings["booking_options"], logistics)

        # 9) Adaptation
        log("Real-Time Adaptation Agent: injecting simulated disruption — BEFORE/AFTER itinerary.")
        def re_eval(d, acts, w, p):
            return self._safety.evaluate(d, acts, w, p)

        adaptation = self._adapt.simulate_and_adapt(
            itinerary,
            dest,
            prefs,
            re_eval,
            chosen,
        )

        # Learning hook (simulated RL feedback — running average of reward)
        global _LEARNING_STATE
        _LEARNING_STATE["plans_generated"] += 1
        _LEARNING_STATE["cumulative_reward"] += float(budget.get("reward_signal", 0))
        learning_snapshot = {
            "plans_generated": _LEARNING_STATE["plans_generated"],
            "average_reward": round(
                _LEARNING_STATE["cumulative_reward"] / _LEARNING_STATE["plans_generated"],
                2,
            ),
            "note": "Simulated policy-quality tracker; in production this would update a model or bandit.",
        }

        # Simulated LLM-style synthesis strings (no API — template reasoning)
        llm_reasoning = self._synthetic_llm_summary(dest, safety, budget, recommendation)

        log("Coordinator: synthesis complete — all agents aligned.")

        return {
            "error": False,
            "steps": steps,
            "parsed_preferences": prefs,
            "research": research,
            "marine_logistics": logistics,
            "weather_used": weather,
            "safety": safety,
            "bookings": bookings,
            "budget": budget,
            "recommendation": recommendation,
            "itinerary": itinerary,
            "adaptation": adaptation,
            "learning": learning_snapshot,
            "llm_style_summary": llm_reasoning,
            "syllabus_map": {
                "multi_agent_collaboration": "Sequential specialist agents with structured handoffs via Coordinator.",
                "reinforcement_signal": "reward_signal and learning average_reward (simulated policy feedback).",
                "utility_decision": "utility_score = experience + safety - cost_penalty.",
                "neuro_symbolic": "JSON rule strings interpreted by Safety agent + numeric scoring.",
                "rag": "CoastalRAGStore token overlap retrieval over three JSON corpora.",
                "human_ai": "Natural-language form input; structured explainable JSON output.",
                "ethics_safety": "Hard filters on marine conditions; blocked activities with reasons.",
            },
        }

    @staticmethod
    def _synthetic_llm_summary(
        dest: dict[str, Any],
        safety: dict[str, Any],
        budget: dict[str, Any],
        rec: dict[str, Any],
    ) -> str:
        return (
            f"Planning trace: prioritize {dest['name']} given corpus match and activity fit. "
            f"Risk band {safety['risk_label']} with overall safety score {safety['overall_safety_score']}. "
            f"Economic objective: estimated spend ₹{budget['estimated_total_inr']:,} "
            f"({'within' if budget['within_budget'] else 'beyond'} stated budget when provided). "
            f"Narrative recommendation: {rec['summary']}"
        )
