"""
Recommendation Agent — merges research scores, utility, and safety for ranking.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class RecommendationAgent:
    def recommend(
        self,
        research: dict[str, Any],
        budget_result: dict[str, Any],
        safety: dict[str, Any],
    ) -> dict[str, Any]:
        primary = research["primary_destination"]
        score = 6.0
        score += min(3, budget_result.get("utility_score", 0) * 0.25)
        score += min(2, safety.get("overall_safety_score", 0) * 0.15)
        if budget_result.get("within_budget"):
            score += 1.0

        reasons = [
            f"Primary destination {primary['name']} aligns with retrieval + preferences.",
            f"Utility-based score favors this plan (utility={budget_result.get('utility_score')}).",
            f"Safety assessment: {safety.get('risk_label')} overall risk band.",
        ]
        if budget_result.get("budget_inr"):
            reasons.append(
                f"Estimated ₹{budget_result['estimated_total_inr']:,} vs budget "
                f"₹{budget_result['budget_inr']:,} ({'within' if budget_result['within_budget'] else 'over'} limits)."
            )

        return {
            "confidence": min(10, round(score, 2)),
            "summary": " ".join(reasons[:2]),
            "detailed_reasons": reasons,
            "top_pick": primary,
            "explanation": "Weighted fusion of RAG retrieval, utility, and safety outputs.",
        }
