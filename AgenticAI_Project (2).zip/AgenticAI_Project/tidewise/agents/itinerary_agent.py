"""
Itinerary Agent — builds day-wise schedule from bookings + logistics.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class ItineraryAgent:
    def build(
        self,
        preferences: dict[str, Any],
        destination: dict[str, Any],
        booking_options: list[dict[str, Any]],
        logistics: dict[str, Any],
    ) -> dict[str, Any]:
        days = preferences.get("duration_days", 4)
        days_list = []
        available = [b for b in booking_options if b.get("available", True)]
        for d in range(1, days + 1):
            if d == 1 and logistics.get("sequence"):
                am = f"Arrival / hub check-in — review marine briefing ({destination['name']})"
                pm = (
                    f"Optional transfer: {logistics['sequence'][0]['leg']} "
                    f"({logistics['sequence'][0]['mode']})"
                    if logistics["sequence"]
                    else "Coastal orientation walk"
                )
            elif available:
                b = available[(d - 2) % len(available)] if d > 1 else available[0]
                am = f"{b['display_name']} ({b['slot']}) — {b['vendor_simulated']}"
                pm = "Sunset beach / recovery; hydrate; check next-day wind forecast"
            else:
                am = "Shore exploration / cultural sites (water activities deferred)"
                pm = "Local cuisine; early rest"

            days_list.append(
                {
                    "day": d,
                    "morning": am,
                    "afternoon": pm,
                    "evening": "Monitor IMD coastal bulletin; confirm operator for next day",
                }
            )

        adaptive_rules = [
            "If wind exceeds operator threshold, shift water blocks to shore skills or theory.",
            "If visibility drops below activity minimum from activity_data.json, auto-substitute lagoon/shore options.",
            "If ferry delay > 60m, compress afternoon block and notify accommodation buffer.",
            "Daily 06:30 IMD + Open-Meteo check before committing offshore legs.",
            "Budget shock >10%: freeze optional add-ons; preserve safety-critical transfers.",
        ]

        return {
            "days": days_list,
            "packing_notes": [
                "Reef-safe sunscreen",
                "Hydration + ORS",
                "Copies of ID for marine permits where applicable",
            ],
            "adaptive_planning_rules": adaptive_rules,
            "explanation": f"Goal-oriented plan covering {days} days anchored at {destination['name']}.",
        }
