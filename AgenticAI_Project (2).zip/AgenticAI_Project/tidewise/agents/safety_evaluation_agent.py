"""
Safety Evaluation Agent — neuro-symbolic: loads activity rules from JSON,
applies them to simulated weather/marine fields.

Ethics: Unsafe combinations are filtered with explicit reasons (transparency).
We avoid recommending activities that violate hard safety rules even if the user
requests them — autonomy stops where preventable harm begins (duty of care).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from tidewise.rag_store import CoastalRAGStore


@dataclass
class SafetyEvaluationAgent:
    rag: CoastalRAGStore

    def evaluate(
        self,
        destination: dict[str, Any],
        activity_ids: list[str],
        weather: dict[str, Any],
        preferences: dict[str, Any],
    ) -> dict[str, Any]:
        visibility_m = weather.get("visibility_m", 8.0)
        wave_m = weather.get("wave_height_m", destination.get("swell_typical_m", 0.8))
        wind_k = weather.get("wind_knots", 12)
        tide = weather.get("tide_strength", "moderate")
        max_user_risk = preferences.get("max_activity_risk_score", 3)

        safe_activities: list[dict[str, Any]] = []
        blocked: list[dict[str, Any]] = []

        for aid in activity_ids:
            spec = self.rag.activity_by_id(aid)
            if not spec:
                blocked.append({"id": aid, "reason": "Unknown activity in corpus"})
                continue

            reasons: list[str] = []
            blocked_flag = False

            if visibility_m < spec["min_visibility_m"]:
                blocked_flag = True
                reasons.append(
                    f"Visibility {visibility_m}m < required {spec['min_visibility_m']}m "
                    f"({spec['display_name']})"
                )
            if wave_m > spec["max_wave_height_m"]:
                blocked_flag = True
                reasons.append(
                    f"Wave height {wave_m}m exceeds max {spec['max_wave_height_m']}m"
                )
            if wind_k > spec["max_wind_knots"]:
                blocked_flag = True
                reasons.append(
                    f"Wind {wind_k}kt exceeds max {spec['max_wind_knots']}kt for {spec['display_name']}"
                )
            if spec["risk_score"] > max_user_risk:
                blocked_flag = True
                reasons.append(
                    f"Activity risk tier {spec['risk_score']} exceeds user max {max_user_risk}"
                )
            if tide == "strong" and aid in ("scuba_diving", "snorkeling") and max_user_risk <= 2:
                blocked_flag = True
                reasons.append("Strong tide + low risk appetite → water entry activities deferred")

            if blocked_flag:
                blocked.append({"id": aid, "reasons": reasons, "rules_fired": spec["symbolic_rules"][:2]})
            else:
                # Safety score 0-10 from margins
                vis_margin = min(10, visibility_m / max(spec["min_visibility_m"], 0.1) * 3)
                wave_margin = max(0, 10 - (wave_m / max(spec["max_wave_height_m"], 0.1)) * 5)
                safety_component = (vis_margin + wave_margin) / 2 - (spec["risk_score"] * 0.4)
                safety_score = max(0, min(10, safety_component))
                safe_activities.append(
                    {
                        "id": aid,
                        "display_name": spec["display_name"],
                        "risk_score": spec["risk_score"],
                        "safety_score": round(safety_score, 2),
                        "symbolic_rules_considered": spec["symbolic_rules"],
                    }
                )

        # Overall label
        if not safe_activities:
            label = "High"
        elif any(a["risk_score"] >= 4 for a in safe_activities):
            label = "Medium"
        else:
            label = "Low"

        overall = sum(a["safety_score"] for a in safe_activities) / max(len(safe_activities), 1)

        return {
            "safe_activities": safe_activities,
            "blocked_activities": blocked,
            "overall_safety_score": round(overall, 2),
            "risk_label": label,
            "weather_snapshot": weather,
            "explanation": (
                f"Symbolic rule engine evaluated {len(activity_ids)} activities; "
                f"{len(safe_activities)} permitted, {len(blocked)} blocked. "
                f"Overall safety score={overall:.1f}/10, label={label}."
            ),
        }
