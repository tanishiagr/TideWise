"""
User Interaction Agent — parses natural-language or structured preferences.

Ethics: We normalize inputs without storing PII; transparency means echoing
parsed constraints back to the user so they can correct misunderstandings.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any


@dataclass
class UserInteractionAgent:
    """Extracts travel constraints from free text (simulated NLU — no paid APIs)."""

    raw_input: str = ""

    # Keyword → destination id (match longer phrases first in _extract_destination)
    DEST_ALIASES: dict[str, str] = field(
        default_factory=lambda: {
            "grand island": "goa_grand_island",
            "calangute": "goa_calangute",
            "baga": "goa_calangute",
            "anjuna": "goa_arambol",
            "arambol": "goa_arambol",
            "palolem": "goa_palolem",
            "havelock": "andaman_havelock",
            "swaraj": "andaman_havelock",
            "port blair": "andaman_port_blair",
            "neil island": "andaman_neil",
            "andaman": "andaman_havelock",
            "nicobar": "andaman_port_blair",
            "lakshadweep": "lakshadweep_agatti",
            "agatti": "lakshadweep_agatti",
            "kovalam": "kerala_kovalam",
            "alleppey": "kerala_alleppey_beach",
            "alappuzha": "kerala_alleppey_beach",
            "bekal": "kerala_bekal",
            "varkala": "kerala_varkala",
            "mahabalipuram": "tamil_mahabalipuram",
            "marina beach": "tamil_marina",
            "marina": "tamil_marina",
            "chennai": "tamil_marina",
            "rameswaram": "tamil_rameswaram",
            "dhanushkodi": "tamil_rameswaram",
            "kanyakumari": "tamil_kanyakumari",
            "puducherry": "puducherry_promenade",
            "pondicherry": "puducherry_promenade",
            "rock beach": "puducherry_promenade",
            "malpe": "karnataka_malpe",
            "udupi": "karnataka_malpe",
            "murudeshwar": "karnataka_murudeshwar",
            "gokarna": "karnataka_gokarna",
            "tarkarli": "maharashtra_tarkarli",
            "malvan": "maharashtra_tarkarli",
            "ganpatipule": "maharashtra_ganpatipule",
            "alibaug": "maharashtra_alibaug",
            "alibag": "maharashtra_alibaug",
            "kashid": "maharashtra_alibaug",
            "juhu": "maharashtra_mumbai_juhu",
            "mumbai": "maharashtra_mumbai_juhu",
            "digha": "westbengal_digha",
            "mandarmani": "westbengal_mandarmani",
            "puri": "odisha_puri",
            "chandipur": "odisha_chandipur",
            "mandvi": "gujarat_mandvi",
            "kutch": "gujarat_mandvi",
            "diu": "gujarat_diu",
            "daman": "damandiu_daman",
            "rushikonda": "andhra_rushikonda",
            "visakhapatnam": "andhra_rushikonda",
            "vizag": "andhra_vizag_ramakrishna",
            "goa": "goa_calangute",
            "kerala": "kerala_varkala",
            "tamil": "tamil_mahabalipuram",
            "tamil nadu": "tamil_mahabalipuram",
            "maharashtra": "maharashtra_tarkarli",
            "karnataka": "karnataka_gokarna",
            "odisha": "odisha_puri",
            "west bengal": "westbengal_digha",
            "gujarat": "gujarat_diu",
            "andhra": "andhra_rushikonda",
        }
    )

    ACTIVITY_ALIASES: dict[str, str] = field(
        default_factory=lambda: {
            "scuba": "scuba_diving",
            "dive": "scuba_diving",
            "snorkel": "snorkeling",
            "surf": "surfing",
            "kayak": "kayaking",
            "island": "island_hopping",
            "hopping": "island_hopping",
        }
    )

    def process(self, raw_text: str) -> dict[str, Any]:
        self.raw_input = raw_text
        text = raw_text.lower()

        budget = self._extract_budget(text)
        dest_hint = self._extract_destination(text)
        activities = self._extract_activities(text)
        risk = self._extract_risk(text)
        group = self._extract_group(text)
        month = self._extract_month(text)

        start_date, end_date = None, None
        m_dates = re.search(r"from\s+(\d{4}-\d{2}-\d{2})\s+to\s+(\d{4}-\d{2}-\d{2})", text, re.I)
        if m_dates:
            start_date, end_date = m_dates.group(1), m_dates.group(2)
            try:
                from datetime import datetime
                d1 = datetime.strptime(start_date, "%Y-%m-%d")
                d2 = datetime.strptime(end_date, "%Y-%m-%d")
                days = max(1, (d2 - d1).days + 1)
            except ValueError:
                days = self._extract_days(text)
        else:
            days = self._extract_days(text)

        max_risk = {"low": 2, "moderate": 3, "high": 5}[risk]

        return {
            "success": True,
            "parsed_preferences": {
                "raw_input": raw_text,
                "destination_id_hint": dest_hint,
                "budget_inr": budget,
                "duration_days": days,
                "start_date": start_date,
                "end_date": end_date,
                "preferred_activity_ids": activities,
                "risk_appetite": risk,
                "max_activity_risk_score": max_risk,
                "group_size": group,
                "travel_month": month,
            },
            "explanation": (
                f"Parsed {days} days, risk={risk}, group={group}, "
                f"budget={'₹' + str(budget) if budget else 'unspecified'}."
            ),
        }

    def _extract_budget(self, text: str) -> int | None:
        matches = re.findall(
            r"(?:budget|₹|rs\.?|inr|rupees?)\s*[:\-]?\s*([0-9][0-9,]*(?:\s*(?:k|lakh))?)",
            text,
            re.I,
        )
        if not matches:
            return None
        
        amounts = []
        for raw_match in matches:
            raw = raw_match.replace(",", "").replace(" ", "")
            if "lakh" in raw:
                amounts.append(int(float(re.findall(r"[\d.]+", raw)[0]) * 100_000))
            elif raw.endswith("k"):
                amounts.append(int(float(raw[:-1]) * 1000))
            else:
                nums = re.findall(r"\d+", raw)
                if nums:
                    amounts.append(int(nums[0]))
        
        if amounts:
            return max(amounts)
        return None

    def _extract_days(self, text: str) -> int:
        m = re.search(r"(\d+)\s*(?:-?\s*)?(?:day|days|night|nights)\b", text, re.I)
        return int(m.group(1)) if m else 4

    def _extract_destination(self, text: str) -> str | None:
        for alias, dest_id in sorted(self.DEST_ALIASES.items(), key=lambda kv: -len(kv[0])):
            if alias in text:
                return dest_id
        return None

    def _extract_activities(self, text: str) -> list[str]:
        found: set[str] = set()
        for alias, aid in self.ACTIVITY_ALIASES.items():
            if alias in text:
                found.add(aid)
        return sorted(found)

    def _extract_risk(self, text: str) -> str:
        if re.search(
            r"safe|family|low risk|beginner|nervous|minimal",
            text,
            re.I,
        ):
            return "low"
        if re.search(r"extreme|thrill|high risk|adrenaline|maximum", text, re.I):
            return "high"
        return "moderate"

    def _extract_group(self, text: str) -> int:
        m = re.search(
            r"(\d+)\s*(?:person|people|pax|travelers?|friends?|couple|group|family)",
            text,
            re.I,
        )
        if m:
            return max(1, int(m.group(1)))
        if "solo" in text or "alone" in text:
            return 1
        return 2

    def _extract_month(self, text: str) -> int:
        months = [
            "jan",
            "feb",
            "mar",
            "apr",
            "may",
            "jun",
            "jul",
            "aug",
            "sep",
            "oct",
            "nov",
            "dec",
        ]
        for i, name in enumerate(months, start=1):
            if name in text:
                return i
        return 4
