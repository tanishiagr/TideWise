"""
Coastal Research Agent — RAG-style retrieval over coastal_data.json.

Does not hardcode destination rankings; scores come from dataset + query overlap.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from tidewise.rag_store import CoastalRAGStore


@dataclass
class CoastalResearchAgent:
    rag: CoastalRAGStore

    def research(self, preferences: dict[str, Any]) -> dict[str, Any]:
        q_parts = [
            preferences.get("raw_input", ""),
            " ".join(preferences.get("preferred_activity_ids", [])),
            preferences.get("destination_id_hint") or "",
        ]
        query = " ".join(p for p in q_parts if p)

        hits = self.rag.retrieve(query, top_k=12)
        dest_scores: dict[str, float] = {}
        for h in hits:
            if "name" in h.payload and "id" in h.payload:
                did = h.payload["id"]
                dest_scores[did] = max(dest_scores.get(did, 0), h.score)

        # Merge explicit hint
        hint = preferences.get("destination_id_hint")
        if hint:
            dest_scores[hint] = dest_scores.get(hint, 0) + 2.0

        ranked = sorted(dest_scores.items(), key=lambda x: x[1], reverse=True)
        candidates = []
        for did, sc in ranked[:6]:
            d = self.rag.get_destination_by_id(did)
            if d:
                candidates.append({"destination": d, "retrieval_score": round(sc, 4)})

        if not candidates:
            for d in self.rag.all_destinations()[:4]:
                candidates.append({"destination": d, "retrieval_score": 0.1})

        primary = candidates[0]["destination"] if candidates else self.rag.all_destinations()[0]

        return {
            "candidates": candidates,
            "primary_destination": primary,
            "rag_hits_sample": [
                {"source": h.source, "chunk_id": h.chunk_id, "score": h.score}
                for h in hits[:5]
            ],
            "explanation": (
                f"Retrieved {len(candidates)} coastal nodes from local JSON corpus; "
                f"primary: {primary['name']} ({primary['state']})."
            ),
        }
