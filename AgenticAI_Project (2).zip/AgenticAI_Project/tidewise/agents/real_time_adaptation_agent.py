"""
Real-Time Adaptation Agent — simulates dynamic world changes and replans.

Uses rule-based adaptation + reward check: prefer changes that recover safety
and keep utility from collapsing.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Callable


@dataclass
class RealTimeAdaptationAgent:
    seed: int = 7

    def simulate_and_adapt(
        self,
        itinerary: dict[str, Any],
        destination: dict[str, Any],
        preferences: dict[str, Any],
        re_eval_safety: Callable[..., dict[str, Any]],
        activity_ids: list[str],
    ) -> dict[str, Any]:
        rng = random.Random(self.seed)
        events = [
            "weather_degrade",
            "budget_cut",
            "ferry_delay",
            "activity_cancellation",
        ]
        event = rng.choice(events)

        before = itinerary["days"]
        after = [dict(day) for day in before]
        adaptation_notes: list[str] = []

        if event == "weather_degrade":
            adaptation_notes.append(
                "Simulated MET alert: wind +12kt, wave height +0.4m for afternoon windows."
            )
            new_weather = {
                "visibility_m": 6.0,
                "wave_height_m": min(2.2, destination.get("swell_typical_m", 0.8) + 0.6),
                "wind_knots": 24,
                "tide_strength": "strong",
            }
            safety = re_eval_safety(destination, activity_ids, new_weather, preferences)
            for row in after:
                if "Scuba" in row["morning"] or "Snorkel" in row["morning"]:
                    row["morning"] = "Switched to shore skills workshop / theory (weather hold)"
                    row["afternoon"] = "Indoor marine conservation briefing + equipment check"
            adaptation_notes.append(
                f"Re-evaluated safety with degraded weather; permitted activities: "
                f"{[a['id'] for a in safety['safe_activities']]}"
            )
        elif event == "budget_cut":
            cut = 0.12
            adaptation_notes.append(f"Simulated budget shock: effective budget reduced by {cut*100:.0f}%.")
            for row in after:
                row["evening"] = (
                    "Budget mode: self-catered dinner; postpone optional add-ons — "
                    + row["evening"]
                )
        elif event == "ferry_delay":
            adaptation_notes.append("Simulated ferry stack delay +90m — compress afternoon block.")
            for row in after[1:]:
                row["afternoon"] = "Shortened block; confirm new boarding QR with operator"
        else:
            adaptation_notes.append("Simulated vendor cancellation for one slot — rotating backup activity.")
            if after:
                after[1]["morning"] = "Backup: guided kayaking → stand-up paddle intro (if winds allow)"

        # Simple adaptation reward heuristic
        reward_delta = 1.5 if event == "weather_degrade" else 0.5
        reward_delta -= 0.5 if event == "budget_cut" else 0

        return {
            "simulated_event": event,
            "adaptation_notes": adaptation_notes,
            "itinerary_before": before,
            "itinerary_after": after,
            "reward_delta_estimate": round(reward_delta, 2),
            "explanation": (
                "Adaptation agent applied event-driven replanning with safety re-check "
                "where weather changed (closed-loop)."
            ),
        }
