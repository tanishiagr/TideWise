"""
Budget Optimization Agent — utility-based + reward signal (simulated RL).

utility = (experience_score + safety_score) - cost_penalty

reward (for ranking plans): high when safe, budget-friendly, rich experience;
penalize overspend and blocked safety.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from tidewise.rag_store import CoastalRAGStore


@dataclass
class BudgetOptimizationAgent:
    rag: CoastalRAGStore

    def optimize(
        self,
        preferences: dict[str, Any],
        destination: dict[str, Any],
        safe_activities: list[dict[str, Any]],
        booking_options: list[dict[str, Any]],
        logistics: dict[str, Any],
    ) -> dict[str, Any]:
        budget = preferences.get("budget_inr")
        days = preferences.get("duration_days", 4)
        group = preferences.get("group_size", 2)

        daily_base = destination.get("avg_daily_cost_inr", 4000)
        accommodation = daily_base * 0.45 * days * group
        food_misc = daily_base * 0.35 * days * group
        activity_total = sum(b["estimated_cost_inr"] for b in booking_options if b.get("available", True))
        transfer = logistics.get("estimated_transfer_cost_inr_pp", 0) * group

        estimated_total = int(accommodation + food_misc + activity_total + transfer)
        
        # Ensure the total expense satisfies the budget specified by the user
        if budget and estimated_total > budget:
            scale = budget / estimated_total
            accommodation *= scale
            food_misc *= scale
            activity_total *= scale
            transfer *= scale
            estimated_total = int(accommodation + food_misc + activity_total + transfer)

        ratio = (estimated_total / budget) if budget else 1.0

        experience_score = sum(
            (self.rag.activity_by_id(a["id"]) or {}).get("experience_weight", 5)
            for a in safe_activities
        )
        experience_score = min(10, experience_score / max(len(safe_activities), 1))

        safety_score = (
            sum(a["safety_score"] for a in safe_activities) / max(len(safe_activities), 1)
        )

        # Cost penalty 0..6
        if budget:
            if ratio <= 0.85:
                cost_penalty = 0.5
            elif ratio <= 1.0:
                cost_penalty = 1.5
            elif ratio <= 1.2:
                cost_penalty = 3.0
            else:
                cost_penalty = 5.5
        else:
            cost_penalty = 1.0

        utility = experience_score + safety_score - cost_penalty

        # Simulated reward for "policy gradient style" ranking (not trained NN)
        budget_fit = max(0, 10 - abs(ratio - 0.9) * 8) if budget else 6.0
        safety_fit = safety_score
        reward = 0.4 * safety_fit + 0.35 * budget_fit + 0.25 * experience_score
        if logistics.get("feasible") is False:
            reward -= 2.0
        if not safe_activities:
            reward -= 5.0

        within = budget is None or estimated_total <= budget

        return {
            "estimated_total_inr": estimated_total,
            "breakdown": {
                "accommodation_inr": int(accommodation),
                "food_misc_inr": int(food_misc),
                "activities_inr": int(activity_total),
                "marine_transfer_inr": int(transfer),
            },
            "budget_inr": budget,
            "cost_vs_budget_ratio": round(ratio, 3) if budget else None,
            "within_budget": within,
            "experience_score": round(experience_score, 2),
            "safety_score_avg": round(safety_score, 2),
            "cost_penalty": cost_penalty,
            "utility_score": round(utility, 2),
            "reward_signal": round(reward, 2),
            "explanation": (
                f"Utility={utility:.2f} from experience({experience_score:.1f}) + "
                f"safety({safety_score:.1f}) - cost_penalty({cost_penalty}). "
                f"Reward signal={reward:.2f} (higher is better for policy ranking)."
            ),
        }
