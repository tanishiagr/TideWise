"""
Marine Logistics Agent — ferry/boat feasibility from logistics_data.json.

Uses graph edges to validate island hops and estimate transfer cost/time.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from tidewise.rag_store import CoastalRAGStore


@dataclass
class MarineLogisticsAgent:
    rag: CoastalRAGStore

    def plan(
        self,
        destination: dict[str, Any],
        activity_ids: list[str],
    ) -> dict[str, Any]:
        graph = self.rag.logistics_graph()
        dest_id = destination["id"]
        edges_out = [e for e in graph["edges"] if e["from"] == dest_id or e["to"] == dest_id]
        island_hop = "island_hopping" in activity_ids

        sequence: list[dict[str, Any]] = []
        total_min = 0
        total_cost = 0
        feasible = True
        notes: list[str] = []

        if island_hop:
            related = [e for e in graph["edges"] if e["from"] == dest_id or e["to"] == dest_id]
            if not related:
                feasible = False
                notes.append(
                    "Island hopping requested but no ferry/boat edges from this hub in dataset — "
                    "plan downgraded to shore-based activities only."
                )
            else:
                for e in related[:3]:
                    sequence.append(
                        {
                            "leg": f"{e['from']} → {e['to']}",
                            "mode": e["mode"],
                            "duration_min": e["duration_min"],
                            "cost_inr_pp": e["cost_inr_per_person"],
                        }
                    )
                    total_min += e["duration_min"]
                    total_cost += e["cost_inr_per_person"]
        else:
            notes.append("No multi-hop marine sequence required for selected activities.")

        return {
            "hub_id": dest_id,
            "feasible": feasible,
            "sequence": sequence,
            "estimated_transfer_minutes": total_min,
            "estimated_transfer_cost_inr_pp": total_cost,
            "edge_count_from_hub": len(edges_out),
            "notes": notes,
            "explanation": (
                f"Logistics graph check for hub `{dest_id}`: {len(edges_out)} connected edges; "
                f"island_hopping feasible={feasible}."
            ),
        }
