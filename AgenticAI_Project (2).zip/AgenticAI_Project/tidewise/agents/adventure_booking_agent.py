"""
Adventure Booking Agent — simulates availability and pricing (no external APIs).
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any

from tidewise.rag_store import CoastalRAGStore


@dataclass
class AdventureBookingAgent:
    rag: CoastalRAGStore
    seed: int = 42

    def simulate_bookings(
        self,
        destination: dict[str, Any],
        safe_activity_specs: list[dict[str, Any]],
        group_size: int,
    ) -> dict[str, Any]:
        rng = random.Random(self.seed + hash(destination["id"]) % 1000)
        options: list[dict[str, Any]] = []
        for spec in safe_activity_specs:
            aid = spec["id"]
            meta = self.rag.activity_by_id(aid)
            base = meta["typical_cost_inr"] if meta else 2000
            surge = rng.choice([0, 0, 0.1, 0.15])
            price = int(base * group_size * (1 + surge))
            slot = rng.choice(["09:00", "11:30", "14:00"])
            avail = rng.random() > 0.15
            options.append(
                {
                    "activity_id": aid,
                    "display_name": spec["display_name"],
                    "slot": slot,
                    "available": avail,
                    "estimated_cost_inr": price,
                    "vendor_simulated": f"CoastalOps-{destination['id']}-{aid[:3]}",
                }
            )

        return {
            "booking_options": options,
            "explanation": (
                "Booking simulation uses deterministic RNG seeded per destination for repeatable demos."
            ),
        }
