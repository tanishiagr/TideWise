"""OpenStreetMap Nominatim (free) — respect usage policy: ≤1 req/s, identify app."""

from __future__ import annotations

from typing import Any

import httpx

NOMINATIM = "https://nominatim.openstreetmap.org"
HEADERS = {"User-Agent": "TideWise-Planner/1.0 (edu demo; local development)"}


def search_place(query: str, timeout: float = 8.0) -> dict[str, Any] | None:
    """Forward geocode; returns first hit or None."""
    q = query.strip()
    if len(q) < 3:
        return None
    params = {"q": q, "format": "json", "limit": 1}
    with httpx.Client(headers=HEADERS, timeout=timeout) as client:
        r = client.get(f"{NOMINATIM}/search", params=params)
        r.raise_for_status()
        data = r.json()
    if not data:
        return None
    hit = data[0]
    return {
        "display_name": hit.get("display_name", ""),
        "lat": float(hit["lat"]),
        "lon": float(hit["lon"]),
        "osm_type": hit.get("osm_type"),
        "importance": hit.get("importance"),
    }


def reverse_geocode(lat: float, lon: float, timeout: float = 8.0) -> dict[str, Any] | None:
    params = {"lat": lat, "lon": lon, "format": "json"}
    with httpx.Client(headers=HEADERS, timeout=timeout) as client:
        r = client.get(f"{NOMINATIM}/reverse", params=params)
        r.raise_for_status()
        data = r.json()
    if not data:
        return None
    addr = data.get("address") or {}
    return {
        "display_name": data.get("display_name", ""),
        "city": addr.get("city") or addr.get("town") or addr.get("village"),
        "state": addr.get("state"),
        "country": addr.get("country"),
        "postcode": addr.get("postcode"),
    }
