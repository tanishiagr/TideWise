"""Open-Meteo Weather + Marine APIs (free, no key)."""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Any

import httpx

MARINE_URL = "https://marine-api.open-meteo.com/v1/marine"
WEATHER_URL = "https://api.open-meteo.com/v1/forecast"


def _kmh_to_knots(kmh: float) -> float:
    return round(kmh / 1.852, 2)


def _suitability(wave_m: float, wind_kn: float, vis_m: float | None) -> str:
    if wave_m > 1.8 or wind_kn > 22:
        return "caution"
    if wave_m > 1.2 or wind_kn > 18:
        return "moderate"
    if vis_m is not None and vis_m < 3000:
        return "moderate"
    return "good"


def fetch_trip_forecast_bundle(
    lat: float,
    lon: float,
    trip_days: int,
    timeout: float = 12.0,
) -> dict[str, Any]:
    """Hourly marine + weather for trip window; falls back to synthetic if APIs fail."""
    fdays = min(8, max(3, trip_days + 1))
    m_params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": ",".join(
            [
                "wave_height",
                "wind_wave_height",
                "swell_wave_height",
                "sea_surface_temperature",
                "wind_speed_10m",
            ]
        ),
        "forecast_days": fdays,
        "timezone": "Asia/Kolkata",
    }
    w_params = {
        "latitude": lat,
        "longitude": lon,
        "hourly": ",".join(
            [
                "temperature_2m",
                "relative_humidity_2m",
                "precipitation_probability",
                "weather_code",
                "visibility",
                "wind_speed_10m",
            ]
        ),
        "forecast_days": fdays,
        "timezone": "Asia/Kolkata",
    }

    marine_h: dict[str, list] = {}
    weather_h: dict[str, list] = {}

    try:
        with httpx.Client(timeout=timeout) as client:
            mr = client.get(MARINE_URL, params=m_params)
            mr.raise_for_status()
            marine_h = mr.json().get("hourly") or {}
            wr = client.get(WEATHER_URL, params=w_params)
            wr.raise_for_status()
            weather_h = wr.json().get("hourly") or {}
    except Exception as exc:
        return {
            "ok": False,
            "error": str(exc),
            "source_apis": ["Open-Meteo (unavailable — using dataset baselines)"],
            "days": [],
        }

    wt = weather_h.get("time") or []
    hours_limit = min(trip_days * 24, len(wt), 24 * fdays)

    def mval(key: str, i: int, default: float) -> float:
        arr = marine_h.get(key) or []
        if i < len(arr) and arr[i] is not None:
            return float(arr[i])
        return default

    by_date: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for ti, t in enumerate(wt[:hours_limit]):
        wave = mval("wave_height", ti, 0.5)
        swell = mval("swell_wave_height", ti, wave)
        sst_raw = marine_h.get("sea_surface_temperature") or []
        sst = float(sst_raw[ti]) if ti < len(sst_raw) and sst_raw[ti] is not None else None
        m_wind_kmh = mval("wind_speed_10m", ti, 10.0)

        air_t = float(weather_h["temperature_2m"][ti]) if weather_h.get("temperature_2m") else 28.0
        rh = float(weather_h["relative_humidity_2m"][ti]) if weather_h.get("relative_humidity_2m") else 70.0
        pprob = (
            float(weather_h["precipitation_probability"][ti])
            if weather_h.get("precipitation_probability")
            else 0.0
        )
        wcode = int(weather_h["weather_code"][ti]) if weather_h.get("weather_code") else 0
        vis = float(weather_h["visibility"][ti]) if weather_h.get("visibility") else None
        w_wind_kmh = float(weather_h["wind_speed_10m"][ti]) if weather_h.get("wind_speed_10m") else m_wind_kmh

        wind_kn = _kmh_to_knots(max(m_wind_kmh, w_wind_kmh))
        row = {
            "time_ist": t,
            "air_temp_c": round(air_t, 1),
            "relative_humidity_pct": round(rh, 0),
            "precipitation_probability_pct": round(pprob, 0),
            "weather_code": wcode,
            "visibility_m": round(vis, 0) if vis is not None else None,
            "wind_speed_kmh": round(max(m_wind_kmh, w_wind_kmh), 1),
            "wind_knots": wind_kn,
            "wave_height_m": round(wave, 2),
            "swell_height_m": round(swell, 2),
            "sea_surface_temp_c": round(sst, 1) if sst is not None else None,
            "marine_suitability": _suitability(wave, wind_kn, vis),
        }
        day_key = t[:10] if len(t) >= 10 else t
        by_date[day_key].append(row)

    days_out = []
    for date_key in sorted(by_date.keys())[:trip_days]:
        days_out.append({"date": date_key, "hours": by_date[date_key]})

    return {
        "ok": True,
        "source_apis": [
            "https://marine-api.open-meteo.com (hourly marine)",
            "https://api.open-meteo.com (hourly weather)",
        ],
        "fetched_at": datetime.utcnow().isoformat() + "Z",
        "trip_window_days": trip_days,
        "days": days_out,
    }
