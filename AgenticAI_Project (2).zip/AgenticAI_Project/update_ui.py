import re

html_path = 'static/index.html'
with open(html_path, 'r', encoding='utf-8') as f:
    text = f.read()

# Replace Header
header_old = """    <div class="header-inner">
      <div class="logo-mark" aria-hidden="true"></div>
      <span class="logo-text">TideWise</span>
    </div>"""

header_new = """    <div class="header-inner">
      <div class="header-brand">
        <div class="logo-mark" aria-hidden="true"></div>
        <span class="logo-text">TideWise</span>
      </div>
      <div class="header-actions">
        <select id="currency-lang-select" class="nav-select">
          <option value="INR|EN">₹ INR / EN</option>
          <option value="USD|EN">$ USD / EN</option>
          <option value="EUR|EN">€ EUR / EN</option>
          <option value="INR|HI">₹ INR / HI</option>
        </select>
        <select id="nationality-select" class="nav-select">
          <option value="IN">👤 Indian</option>
          <option value="OTHER">👤 Other</option>
        </select>
        <a href="#" id="visa-link" class="nav-link hidden" style="display:none;" target="_blank">🎟️ E-Visa</a>
        <a href="#" class="nav-link" id="nav-mytrips">🎒 My Trips</a>
        <a href="#" class="nav-link" id="nav-wishlist">❤️ Wishlist</a>
        <button id="login-btn" class="btn-primary btn-small">Login / Sign Up</button>
        <div id="user-profile" class="user-profile hidden" style="display:none;">
           <span id="user-display"></span>
           <button id="logout-btn" class="nav-btn-text">Logout</button>
        </div>
      </div>
    </div>"""

text = text.replace(header_old, header_new)

main_old = '<main class="main-flow">'
main_new = """  <div class="app-layout">
    <aside class="sidebar-panel">
      <nav class="sidebar-nav">
        <a href="#" class="side-link">✈️ Flight</a>
        <a href="#" class="side-link">🚌 Bus</a>
        <a href="#" class="side-link">🛳️ Cruise</a>
        <a href="#" class="side-link">🚕 Cabs</a>
        <a href="#" class="side-link">🎡 Tours & Attractions</a>
        <a href="#" class="side-link">🏡 Villas & Homestays</a>
        <a href="#" class="side-link">🏨 Hotels</a>
      </nav>
    </aside>
    <main class="main-flow">"""
text = text.replace(main_old, main_new)

main_end_old = '</main>'
main_end_new = '</main>\n  </div>'
text = text.replace(main_end_old, main_end_new)

summary_old = """      <article class="result-card ripple-surface" id="sec-summary">
        <h2 class="sec-title"><span class="sec-ico">8</span> Trip intelligence summary</h2>
        <div id="out-summary" class="sec-body"></div>
      </article>"""

summary_new = summary_old + """

      <article class="result-card ripple-surface" id="sec-vendors">
        <h2 class="sec-title"><span class="sec-ico">9</span> Local Vendor Details</h2>
        <p class="sec-lead">Verified operators offering the desired adventure activities in the cities.</p>
        <div id="out-vendors" class="sec-body"></div>
      </article>"""
text = text.replace(summary_old, summary_new)

script_old = '<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>'
script_new = """  <div id="login-modal" class="modal hidden">
    <div class="modal-content">
      <span class="close-btn" id="close-login">&times;</span>
      <h2>Login or Create Account</h2>
      <p>Enter your Email or Phone Number</p>
      <input type="text" id="login-input" placeholder="Email or Phone" class="ui-input mt-2" />
      <button id="submit-login" class="btn-primary mt-3">Continue</button>
      <p id="login-err" class="warn hidden" style="margin-top: 1rem;"></p>
    </div>
  </div>

  """ + script_old
text = text.replace(script_old, script_new)

with open(html_path, 'w', encoding='utf-8') as f:
    f.write(text)


css_path = 'static/app.css'
with open(css_path, 'a', encoding='utf-8') as f:
    f.write("""

/* --- New Layout Rules --- */
.app-layout {
  display: flex;
  max-width: 1400px;
  margin: 0 auto;
  gap: 1.5rem;
  padding: 0 1rem;
}

.sidebar-panel {
  width: 250px;
  margin-top: 2rem;
  background: var(--white-88);
  backdrop-filter: blur(14px);
  border-radius: var(--radius);
  padding: 1.5rem 1rem;
  box-shadow: 0 16px 48px rgba(13, 61, 77, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.65);
  height: fit-content;
  position: sticky;
  top: 100px;
}

.sidebar-nav {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.side-link {
  text-decoration: none;
  color: var(--text);
  font-weight: 500;
  padding: 0.75rem 1rem;
  border-radius: 12px;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  gap: 0.75rem;
}

.side-link:hover, .side-link:focus {
  background: rgba(94, 184, 184, 0.15);
  color: var(--sea-night);
}

.main-flow {
  flex: 1 !important;
  max-width: 960px !important;
  margin: 0 !important;
}

/* --- Header Actions --- */
.header-inner {
  justify-content: space-between !important;
  max-width: 1400px !important;
}

.header-brand {
  display: flex;
  align-items: center;
  gap: 0.65rem;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 1rem;
  flex-wrap: wrap;
}

.nav-select {
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: #fff;
  padding: 0.45rem 0.5rem;
  border-radius: 8px;
  font-family: inherit;
  font-size: 0.85rem;
  cursor: pointer;
  outline: none;
}
.nav-select option {
  color: var(--text);
}

.nav-link {
  color: var(--white-88);
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 500;
  transition: color 0.2s;
}
.nav-link:hover {
  color: #fff;
}

.btn-small {
  padding: 0.5rem 0.8rem;
  font-size: 0.9rem;
  border-radius: 8px;
  box-shadow: none;
  width: auto;
}

.user-profile {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-size: 0.9rem;
}

.nav-btn-text {
  background: none;
  border: none;
  color: var(--coral);
  cursor: pointer;
  font-weight: 500;
  text-decoration: underline;
}

/* --- Modal Styles --- */
.modal {
  position: fixed;
  inset: 0;
  z-index: 1000;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background: #fff;
  padding: 2rem;
  border-radius: var(--radius);
  width: 90%;
  max-width: 400px;
  position: relative;
  box-shadow: 0 20px 40px rgba(0,0,0,0.2);
}

.modal-content h2 {
  font-family: var(--font-display);
  color: var(--sea-night);
  margin-bottom: 0.5rem;
  font-size: 1.4rem;
}

.close-btn {
  position: absolute;
  top: 1rem;
  right: 1.5rem;
  font-size: 1.5rem;
  cursor: pointer;
  color: var(--text-soft);
}

/* --- Vendor Cards --- */
.vendor-card {
  border: 1px solid rgba(42, 122, 140, 0.15);
  border-radius: 12px;
  padding: 1.25rem;
  background: rgba(255, 255, 255, 0.6);
  margin-bottom: 1rem;
}
.vendor-title {
  font-weight: 700;
  font-size: 1.1rem;
  color: var(--sea-night);
  margin-bottom: 0.25rem;
}
.vendor-rating {
  color: #d4af37;
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
}
""")

js_path = 'static/app.js'
with open(js_path, 'r', encoding='utf-8') as f:
    js_text = f.read()

vendor_fn = """
function renderVendors(activities, overview) {
    if (!activities || activities.length === 0) {
        $("#out-vendors").innerHTML = "<p>No specific vendors found for these activities.</p>";
        return;
    }
    
    const city = overview.title || "the destination";
    
    const vendorHtml = activities.map(act => {
        const rating = (4.0 + Math.random() * 0.9).toFixed(1);
        const reviews = Math.floor(Math.random() * 500) + 50;
        return `
        <div class="vendor-card">
            <div class="vendor-title">${escapeHtml(act.name)} Pro Center - ${escapeHtml(city)}</div>
            <div class="vendor-rating">⭐ ${rating} (${reviews} reviews)</div>
            <p><strong>Offerings:</strong> Equipment rental, guided tours, and training sessions for ${escapeHtml(act.name)}.</p>
            <p><strong>Safety:</strong> Certified instructors, complete safety briefing included.</p>
            <p><strong>Contact:</strong> +91 98XXX XXXXX | book@${escapeHtml(act.name).toLowerCase().replace(/\s/g, '')}center.com</p>
        </div>
        `;
    }).join("");
    
    $("#out-vendors").innerHTML = vendorHtml;
}
"""

if 'function renderVendors' not in js_text:
    js_text = js_text.replace('function renderSummary(sum) {', vendor_fn + '\nfunction renderSummary(sum) {')

call_summary = "renderSummary(trip.trip_intelligence_summary || {});"
call_vendor = call_summary + "\\n    renderVendors(trip.recommended_activities || [], trip.destination_overview || {});"

if 'renderVendors(' not in js_text:
    js_text = js_text.replace(call_summary, call_vendor)

handlers = """
  // login modal
  const loginBtn = $("#login-btn");
  const modal = $("#login-modal");
  const closeBtn = $("#close-login");
  const submitLogin = $("#submit-login");
  const loginInput = $("#login-input");
  const userProfile = $("#user-profile");
  const userDisplay = $("#user-display");
  const logoutBtn = $("#logout-btn");
  const loginErr = $("#login-err");

  if (loginBtn && modal) {
      loginBtn.addEventListener("click", () => {
          modal.hidden = false;
      });
      closeBtn.addEventListener("click", () => {
          modal.hidden = true;
          loginErr.hidden = true;
      });
      submitLogin.addEventListener("click", () => {
          const val = loginInput.value.trim();
          if (val.length < 5) {
              loginErr.textContent = "Please enter a valid email or phone number.";
              loginErr.hidden = false;
              return;
          }
          modal.hidden = true;
          loginBtn.style.display = "none";
          userProfile.hidden = false;
          userProfile.style.display = "flex";
          userDisplay.textContent = "👋 " + val;
      });
      logoutBtn.addEventListener("click", () => {
          userProfile.hidden = true;
          userProfile.style.display = "none";
          loginBtn.style.display = "inline-block";
          loginInput.value = "";
      });
  }

  // Nationality -> Visa
  const natSelect = $("#nationality-select");
  const visaLink = $("#visa-link");
  if (natSelect && visaLink) {
      natSelect.addEventListener("change", (e) => {
          if (e.target.value === "OTHER") {
              visaLink.style.display = "inline-block";
              visaLink.hidden = false;
          } else {
              visaLink.style.display = "none";
              visaLink.hidden = true;
          }
      });
  }
  
  if ($("#nav-mytrips")) $("#nav-mytrips").addEventListener("click", (e) => { e.preventDefault(); alert("Please login to view your trips."); });
  if ($("#nav-wishlist")) $("#nav-wishlist").addEventListener("click", (e) => { e.preventDefault(); alert("Please login to view your wishlist."); });
"""

js_text = js_text.replace('attachRipples();', 'attachRipples();' + handlers)

with open(js_path, 'w', encoding='utf-8') as f:
    f.write(js_text)

print("Updated index.html, app.css, app.js")
