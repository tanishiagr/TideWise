/**
 * TideWise traveler UI — OpenStreetMap (Leaflet) + trip sections from /api/plan
 */

const $ = (sel) => document.querySelector(sel);

function escapeHtml(t) {
  if (t == null) return "";
  const d = document.createElement("div");
  d.textContent = String(t);
  return d.innerHTML;
}

function fmtMoney(n) {
  if (n == null || n === "") return "—";
  return "₹" + Number(n).toLocaleString("en-IN");
}

let mapInstance = null;
let mapMarker = null;

function initOrUpdateMap(lat, lon, title) {
  const el = $("#dest-map");
  if (!el || typeof L === "undefined") return;
  if (mapInstance) {
    mapInstance.setView([lat, lon], 12);
    if (mapMarker) mapMarker.setLatLng([lat, lon]);
    else mapMarker = L.marker([lat, lon]).addTo(mapInstance).bindPopup(escapeHtml(title)).openPopup();
    return;
  }
  mapInstance = L.map(el, { scrollWheelZoom: true }).setView([lat, lon], 12);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  }).addTo(mapInstance);
  mapMarker = L.marker([lat, lon]).addTo(mapInstance).bindPopup(escapeHtml(title)).openPopup();
  setTimeout(() => mapInstance.invalidateSize(), 300);
}

function renderDestination(overview) {
  const coords = overview.coordinates || {};
  const lat = coords.latitude;
  const lon = coords.longitude;
  const w = overview.water_temperature_c || {};
  const vis = overview.visibility_m || {};
  const wav = overview.waves_m || {};
  const cr = overview.crowd || {};

  $("#out-dest").innerHTML = `
    <p class="pill">${escapeHtml(overview.state || "")}${overview.region ? " · " + escapeHtml(overview.region) : ""}</p>
    <h3 class="dest-name">${escapeHtml(overview.title || "")}</h3>
    ${overview.nominatim_display_name ? `<p class="nominatim-line"><strong>📍 Location:</strong> ${escapeHtml(overview.nominatim_display_name)}</p>` : ""}
    <p>🌅 ${escapeHtml(overview.description || "")}</p>
    <p>🗺️ <a href="${escapeHtml(overview.openstreetmap_url)}" target="_blank" rel="noopener">Open exact location in OpenStreetMap ↗</a></p>
    <div class="stat-grid">
      <div class="stat-cell"><span>Water temp (typical °C)</span><strong>${escapeHtml(w.typical_min)}–${escapeHtml(w.typical_max)}</strong></div>
      <div class="stat-cell"><span>Visibility (dataset, m)</span><strong>${escapeHtml(vis.dataset_typical)}</strong></div>
      <div class="stat-cell"><span>Forecast vis day 1 (m)</span><strong>${vis.forecast_day1_avg_m != null ? escapeHtml(vis.forecast_day1_avg_m) : "—"}</strong></div>
      <div class="stat-cell"><span>Avg waves (dataset, m)</span><strong>${escapeHtml(wav.dataset_typical_avg_height)}</strong></div>
      <div class="stat-cell"><span>Forecast waves day 1 (m)</span><strong>${wav.forecast_day1_avg_height != null ? escapeHtml(wav.forecast_day1_avg_height) : "—"}</strong></div>
      <div class="stat-cell"><span>Crowd</span><strong>${escapeHtml(cr.level)} (${escapeHtml(cr.index_1_to_10)}/10)</strong></div>
    </div>
    <div class="badge-row">
      ${(overview.adventure_options || [])
        .map((o) => `<span class="pill">${escapeHtml(o.label || o.id)}</span>`)
        .join("")}
    </div>
  `;

  if (lat != null && lon != null) {
    requestAnimationFrame(() => initOrUpdateMap(lat, lon, overview.title));
  }
}

function suitClass(s) {
  if (s === "good") return "suit-good";
  if (s === "moderate") return "suit-mod";
  return "suit-caution";
}

function renderForecast(smf) {
  const fb = smf.forecast_bundle || {};
  const days = fb.days || [];
  let html = "";

  if (!fb.ok) {
    html = `<p class="warn">⚠️ Live forecast unavailable (${escapeHtml(fb.error || "network")}). Marine planning uses dataset baselines and safety rules only.</p>`;
  } else {
    // Check if dates are within 10 days
    const today = new Date();
    today.setHours(0,0,0,0);
    
    let isWithin10Days = false;
    if (days.length > 0) {
      const firstDateParts = days[0].date.split('-');
      if (firstDateParts.length === 3) {
        const firstDayObj = new Date(firstDateParts[0], firstDateParts[1] - 1, firstDateParts[2]);
        const diffDays = Math.floor((firstDayObj - today) / (1000 * 60 * 60 * 24));
        isWithin10Days = diffDays <= 10;
      } else {
        isWithin10Days = true; // Fallback
      }
    }

    // Prepare Google Weather UI
    let gwHtml = `<div class="google-weather-card">`;
    
    if (isWithin10Days) {
      // Get first day's hours
      const firstDay = days[0] || {};
      const hrs = firstDay.hours || [];
      const currentHr = hrs.length > 0 ? hrs[Math.floor(hrs.length / 2)] : {}; // Approximate
      const currentTemp = currentHr.air_temp_c != null ? currentHr.air_temp_c + "°" : "--°";
      let mainIcon = "☀️";
      if ((currentHr.precipitation_probability_pct || 0) > 20) mainIcon = "🌧️";
      else if ((currentHr.cloud_cover || 0) > 50) mainIcon = "☁️";

      gwHtml += `
      <div class="gw-header">
        <div class="gw-current">
          <div class="gw-icon-big">${mainIcon}</div>
          <div>
            <div class="gw-temp-big">${currentTemp}</div>
            <div class="gw-desc">Detailed 24-hr Forecast</div>
          </div>
        </div>
      </div>
      <div class="gw-hourly">
        ${hrs.map(h => {
          let weatherEmoji = h.precipitation_probability_pct > 20 ? "🌧️" : (h.cloud_cover > 50 ? "☁️" : "☀️");
          const timeLabel = h.time_ist ? h.time_ist.slice(11, 16) : "--:--";
          return `
          <div class="gw-hour-item">
            <div class="gw-hour-time">${timeLabel}</div>
            <div class="gw-hour-icon">${weatherEmoji}</div>
            <div class="gw-hour-temp">${h.air_temp_c}°</div>
          </div>`;
        }).join("")}
      </div>
      `;
    } else {
      gwHtml += `
      <div class="gw-header">
        <div class="gw-current">
          <div class="gw-icon-big">📅</div>
          <div>
            <div class="gw-temp-big">--°</div>
            <div class="gw-desc">General Prediction (>10 days)</div>
          </div>
        </div>
      </div>
      `;
    }

    // Daily summary for all days
    gwHtml += `<div class="gw-daily">`;
    const daysToShow = isWithin10Days ? days.slice(1) : days;
    daysToShow.forEach(d => {
      let high = -100;
      let low = 100;
      let rainRisk = false;
      const hrs = d.hours || [];
      hrs.forEach(h => {
        if (h.air_temp_c > high) high = h.air_temp_c;
        if (h.air_temp_c < low) low = h.air_temp_c;
        if (h.precipitation_probability_pct > 20) rainRisk = true;
      });
      if (high === -100) high = "--";
      if (low === 100) low = "--";
      
      const dayIcon = rainRisk ? "🌧️" : "☁️";
      gwHtml += `
      <div class="gw-day-item">
        <div class="gw-day-name">${escapeHtml(d.date)}</div>
        <div class="gw-day-icon">${dayIcon}</div>
        <div class="gw-day-temps">
          <span class="low">${low}°</span>
          <span class="high">${high}°</span>
        </div>
      </div>`;
    });
    gwHtml += `</div>`;

    // Marine stats area
    const st = smf.trip_hour_statistics || {};
    gwHtml += `
      <div class="gw-marine-info">
        <strong>🌊 Marine Safety:</strong> ${escapeHtml(smf.risk_label)} (Score: ${escapeHtml(smf.overall_safety_score)}/10)<br>
        <strong>⚠️ Non-ideal flags:</strong> ${escapeHtml(st.hours_with_non_good_marine)} hrs<br>
        <div style="margin-top: 0.5rem; font-size: 0.85em; opacity: 0.8;">
          ${(smf.blocked_activities || []).length > 0 ? "Blocked: " + smf.blocked_activities.map(b => escapeHtml(b.id)).join(", ") : "All activities permitted."}
        </div>
      </div>
    </div>`;
    
    html += gwHtml;
  }

  $("#out-forecast").innerHTML = html;
}

function renderActivities(rows) {
  const cards = (rows || []).map(r => {
    let keyword = r.name.split(" ")[0].toLowerCase();
    let imgSrc = `https://loremflickr.com/400/250/${encodeURIComponent(keyword)},beach/all`;
    return `
      <div class="activity-card">
        <div class="activity-img" style="background-image: url('${imgSrc}');"></div>
        <div class="activity-info">
          <h4>${escapeHtml(r.name)}</h4>
          <p><strong>⚠️ Risk:</strong> ${r.risk_tier} | <strong>🦺 Safety:</strong> ${r.safety_score != null ? r.safety_score : "—"}/10</p>
          <p><strong>💰 Price:</strong> ${fmtMoney(r.typical_cost_inr)} (Typical) / ${fmtMoney(r.estimated_booking_inr)} (Simulated)</p>
          <p><strong>🧠 ML Fit Score:</strong> ${r.ml_preference_fit_score}</p>
          <p><strong>🎟️ Booking:</strong> ${r.booking_available ? "✅ Available" : "❌ Not available"}</p>
        </div>
      </div>
    `;
  }).join("");

  $("#out-activities").innerHTML = `
    <p>🤖 Ranked with <strong>scikit-learn GradientBoostingRegressor</strong> (synthetic training) + safety filters.</p>
    <div class="activity-grid">
      ${cards}
    </div>
  `;
}

function renderLogistics(lb) {
  const b = lb.budget || {};
  const lg = lb.marine_logistics || {};
  const br = b.breakdown || {};
  
  let sequenceHtml = (lg.sequence || []).map((step, idx) => {
    let content = step.description || step.detail || step.name;
    if (!content && typeof step === 'object') {
      const rest = { ...step };
      delete rest.type;
      content = Object.entries(rest).map(([k,v]) => `${k.replace(/_/g, ' ')}: ${v}`).join(' &bull; ');
    }
    return `
    <div class="logistics-step">
      <div class="step-num">${idx + 1}</div>
      <div class="step-content">
        <strong>${escapeHtml(step.type || "Logistics")}</strong>: ${escapeHtml(content || "Travel coordination")}
      </div>
    </div>
  `}).join("");

  let cleanExplanation = lg.explanation || "";
  cleanExplanation = cleanExplanation
    .replace(/Logistics graph check for hub (\w+|`.*?`):/i, "Local transport network analyzed:")
    .replace(/(\d+) connected edges/i, "$1 reliable transit routes confirmed")
    .replace(/island_hopping feasible=True/i, "Inter-island/regional transfers are fully supported")
    .replace(/island_hopping feasible=False/i, "Regional transfers are limited here")
    .replace(/;/g, ".");

  $("#out-logistics").innerHTML = `
    <p>🧮 <strong>Feasibility:</strong> ${lg.feasible ? "✅ Routes OK" : "⚠️ Needs revision"} &bull; ${escapeHtml(cleanExplanation)}</p>
    <div class="logistics-timeline">
      ${sequenceHtml}
    </div>
    <div class="stat-grid">
      <div class="stat-cell"><span>Total estimate</span><strong>${fmtMoney(b.estimated_total_inr)}</strong></div>
      <div class="stat-cell"><span>Utility</span><strong>${escapeHtml(b.utility_score)}</strong></div>
      <div class="stat-cell"><span>Reward (sim.)</span><strong>${escapeHtml(b.reward_signal)}</strong></div>
      <div class="stat-cell"><span>Budget fit</span><strong>${b.within_budget ? "✅ Within" : "⚠️ Over / flex"}</strong></div>
    </div>
    <p>🛌 Accommodation ${fmtMoney(br.accommodation_inr)} · 🍲 Food/misc ${fmtMoney(br.food_misc_inr)} · 🏄 Activities ${fmtMoney(br.activities_inr)} · 🛥️ Marine transfer ${fmtMoney(br.marine_transfer_inr)}</p>
  `;
}

function renderGear(eq) {
  const ops = (eq.local_operators || [])
    .map(
      (o) =>
        `<li><strong>${escapeHtml(o.name)}</strong> (${escapeHtml(o.type)}) — rating ~${escapeHtml(o.indicative_rating)} · ${escapeHtml(o.cert_note || "")}</li>`
    )
    .join("");
  const gear = (eq.recommended_equipment || []).map((g) => `<li>${escapeHtml(g)}</li>`).join("");
  $("#out-gear").innerHTML = `
    <h4>Simulated local operators</h4>
    <ul>${ops}</ul>
    <h4>Equipment checklist</h4>
    <ul>${gear}</ul>
    <p>${escapeHtml(eq.certification_reminder || "")}</p>
  `;
}

function renderItinerary(ai) {
  const rules = (ai.adaptive_planning_rules || []).map((r) => `<li>${escapeHtml(r)}</li>`).join("");
  const days = (ai.days_after_adaptation || []).map(
    (d) =>
      `<div class="itin-day"><strong>Day ${d.day}</strong><br>
      <strong>Morning:</strong> ${escapeHtml(d.morning)}<br>
      <strong>Afternoon:</strong> ${escapeHtml(d.afternoon)}<br>
      <strong>Evening:</strong> ${escapeHtml(d.evening)}</div>`
  );
  const notes = (ai.adaptation_notes || []).map((n) => `<li>${escapeHtml(n)}</li>`).join("");
  $("#out-itin").innerHTML = `
    <p><strong>Simulated disruption:</strong> ${escapeHtml(ai.simulated_disruption)}</p>
    <ul>${notes}</ul>
    <h4>Adaptive rules (planning policy)</h4>
    <ul class="rules-list">${rules}</ul>
    <h4>Schedule (post-adaptation)</h4>
    ${days.join("")}
    <h4>Packing</h4>
    <ul>${(ai.packing_notes || []).map((p) => `<li>${escapeHtml(p)}</li>`).join("")}</ul>
  `;
}

function renderEmergency(em) {
  const skip = new Set(["destination_context", "disclaimer"]);
  let html = `<p><strong>Area:</strong> ${escapeHtml(em.destination_context || "")}</p><ul>`;
  Object.entries(em).forEach(([k, v]) => {
    if (skip.has(k)) return;
    html += `<li><strong>${escapeHtml(k)}:</strong> ${escapeHtml(v)}</li>`;
  });
  html += `</ul><p class="sec-lead">${escapeHtml(em.disclaimer || "")}</p>`;
  $("#out-emergency").innerHTML = html;
}

function renderSummary(sum, lb) {
  const bullets = (sum.bullets || []).map((b) => `<li>${escapeHtml(b)}</li>`).join("");
  
  let breakdownHtml = "";
  if (lb && lb.budget && lb.budget.breakdown) {
    const bd = lb.budget.breakdown;
    const total = lb.budget.estimated_total_inr;
    breakdownHtml = `
      <div class="budget-breakdown-summary mt-3">
        <h4 style="margin-bottom: 0.5rem; color: var(--sea-dark)">Total Trip Expense Breakdown</h4>
        <p style="margin-bottom: 1rem; color: var(--text-muted)">The algorithm has optimized your itinerary to ensure expenses satisfy your specified budget range:</p>
        <div class="stat-grid" style="margin-bottom: 1.5rem;">
          <div class="stat-cell"><span style="color: var(--sea-mid);">Total Expense</span><strong style="color: var(--sea-night); font-size: 1.1em;">${fmtMoney(total)}</strong></div>
          <div class="stat-cell"><span>Accommodation</span><strong>${fmtMoney(bd.accommodation_inr)}</strong></div>
          <div class="stat-cell"><span>Food & Misc</span><strong>${fmtMoney(bd.food_misc_inr)}</strong></div>
          <div class="stat-cell"><span>Activities</span><strong>${fmtMoney(bd.activities_inr)}</strong></div>
          <div class="stat-cell"><span>Transfers</span><strong>${fmtMoney(bd.marine_transfer_inr)}</strong></div>
        </div>
      </div>
    `;
  }

  $("#out-summary").innerHTML = `
    <h3>${escapeHtml(sum.headline || "")}</h3>
    <ul class="rules-list" style="margin-bottom: 1.5rem;">${bullets}</ul>
    ${breakdownHtml}
    <p><strong>Data sources:</strong> ${(sum.data_sources || []).map(escapeHtml).join(", ")}</p>
  `;
}

function renderVendors(activities, destOverview) {
  if (!activities || activities.length === 0) {
    $("#out-vendors").innerHTML = "<p>No specific adventure activities returned to find operator details.</p>";
    return;
  }
  
  const city = destOverview ? (destOverview.title || destOverview.nominatim_display_name || "the coast") : "the coast";
  const cityShort = city.split(',')[0].trim();
  
  let html = `<div class="vendor-activity-list">`;
  activities.forEach((act, idx) => {
    const actName = escapeHtml(act.name || String(act));
    html += `<div class="activity-vendor-group">
               <h4 class="activity-vendor-title">Top Providers for ${actName} closely near ${escapeHtml(cityShort)}</h4>
               <div class="vendor-cards-row">`;
               
    const adjectives = ["Pro", "Extreme", "Ultimate", "Local", "Premium", "Coastal", "Sunset", "Oceanic", "Breeze", "Wave", "Reef", "Aqua"];
    const baseAddresses = ["Beach Road", "Main Pier", "Downtown Coast", "Fisherman's Jetty", "Lighthouse Ave", "Seaview Walk"];
    
    // Seeded random approach based on activity string length and index so it's consistent if the same activity is generated
    const s1 = (actName.length + idx * 3) % adjectives.length;
    const s2 = (actName.length * 2 + idx) % adjectives.length;
    const s3 = (actName.length * 5 + idx * 7) % adjectives.length;
    
    const addr1 = (cityShort.length + s1) % baseAddresses.length;
    const addr2 = (cityShort.length + s2 + 1) % baseAddresses.length;
    const addr3 = (cityShort.length + s3 + 2) % baseAddresses.length;
    
    const vendorPool = [
      { 
        name: `${cityShort} ${actName} ${adjectives[s1] || "Centre"}`, 
        rating: (4.1 + (s1 % 9) / 10).toFixed(1), 
        reviews: 80 + s1 * 17, 
        price: `₹${1500 + s1 * 150}`, 
        timings: "08:00 AM - 04:00 PM", 
        address: `Shop ${s1 + 1}, ${baseAddresses[addr1] || "Beach Road"}, ${cityShort}`
      },
      { 
        name: `${adjectives[s2] || "Blue"} ${actName} Experiences`, 
        rating: (4.3 + (s2 % 7) / 10).toFixed(1), 
        reviews: 50 + s2 * 25, 
        price: `₹${1800 + s2 * 200}`, 
        timings: "09:00 AM - 05:00 PM", 
        address: `Pier ${s2 + 2}, ${baseAddresses[addr2] || "Main Pier"}, ${cityShort}`
      },
      { 
        name: `The ${cityShort} ${actName} Hub`, 
        rating: (4.5 + (s3 % 5) / 10).toFixed(1), 
        reviews: 120 + s3 * 30, 
        price: `₹${1200 + s3 * 100}`, 
        timings: "07:00 AM - 12:00 PM", 
        address: `Plot ${s3 + 5}, ${baseAddresses[addr3] || "Seaview Walk"}, ${cityShort}`
      }
    ];

    const selectedVendors = vendorPool;
    
    selectedVendors.forEach(v => {
      const isW = typeof isWishlisted === 'function' && isWishlisted(actName, v.name);
      html += `
        <div class="vendor-card">
          <div class="vendor-header" style="display: flex; justify-content: space-between; align-items: flex-start; gap: 0.5rem;">
            <h4 style="margin: 0;">${v.name}</h4>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <span class="vendor-rating" style="white-space: nowrap;">⭐ ${v.rating} (${v.reviews})</span>
              <button class="wishlist-btn" onclick="toggleWishlist(this, '${actName}', '${v.name}', '${v.price}', '${v.rating}')" title="Add to wishlist" style="font-size: 1.2rem; background: none; border: none; cursor: pointer; color: ${isW ? '#e0845a' : '#aaa'}; transition: transform 0.2s; padding: 0; display: flex; align-items: center;">
                ${isW ? '❤️' : '🤍'}
              </button>
            </div>
          </div>
          <div class="vendor-details">
            <p><strong>Price:</strong> ${v.price} per person</p>
            <p><strong>Timings:</strong> ${v.timings}</p>
            <p><strong>Address:</strong> ${v.address}</p>
            <p>🗺️ <a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(v.name + " " + v.address)}" target="_blank" rel="noopener" style="color: var(--sea-mid); text-decoration: underline;">Open in Google Maps ↗</a></p>
          </div>
          <div class="vendor-actions">
            <button type="button" class="btn-secondary ripple-surface" onclick="openBookingModal('${actName}', '${v.name}', '${v.price}')">Select & Book</button>
          </div>
        </div>
      `;
    });
    
    html += `</div></div>`;
  });
  html += `</div>`;

  $("#out-vendors").innerHTML = html;
}

function renderTechnical(td) {
  if (!td) return;
  $("#tech-pipeline").textContent = td.execution_pipeline_ascii || "";
  $("#tech-agents").innerHTML = (td.specialized_agents || []).map((a) => `<li>${escapeHtml(a)}</li>`).join("");
  $("#tech-trace").innerHTML = (td.live_agent_trace || []).map((s) => `<div>${escapeHtml(s)}</div>`).join("");
  $("#tech-llm").textContent = td.simulated_llm_style_synthesis || "";
  $("#tech-learn").textContent = JSON.stringify(td.learning_snapshot || {}, null, 2);
  const sy = td.syllabus_alignment || {};
  $("#tech-syllabus").innerHTML = Object.entries(sy)
    .map(([k, v]) => `<li><strong>${escapeHtml(k)}</strong> — ${escapeHtml(v)}</li>`)
    .join("");
}

function attachRipples() {
  document.addEventListener(
    "click",
    (e) => {
      const el = e.target.closest(".ripple-surface");
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const ink = document.createElement("span");
      ink.className = "click-ripple";
      ink.style.left = `${e.clientX - rect.left}px`;
      ink.style.top = `${e.clientY - rect.top}px`;
      el.appendChild(ink);
      ink.addEventListener("animationend", () => ink.remove());
    },
    true
  );
}

let currentBooking = {};

window.performLogin = function() {
  const email = $("#login-email").value;
  if (!email) {
    alert("Please enter a valid email or phone number.");
    return;
  }
  localStorage.setItem("tidewise_user", email);
  alert("Verification successful! You are now logged in.");
  $("#login-modal").style.display = "none";
};

window.openBookingModal = function(activity, vendor, price) {
  currentBooking = { activity, vendor, price };
  $("#booking-details-text").textContent = `Activity: ${activity} | Provider: ${vendor} | Price: ${price} per person`;
  
  const registeredUser = localStorage.getItem("tidewise_user");
  $("#booking-email").value = registeredUser && registeredUser.includes("@") ? registeredUser : "";
  
  $("#booking-modal").style.display = "flex";
}

window.submitBooking = async function() {
  const email = $("#booking-email").value;
  if (!email || !email.includes("@")) {
    alert("Please enter a valid email address.");
    return;
  }
  
  const btn = $("#confirm-booking-btn");
  const origText = btn.textContent;
  btn.textContent = "Processing...";
  btn.disabled = true;

  try {
    const res = await fetch("/api/book", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: email,
        activity: currentBooking.activity,
        vendor: currentBooking.vendor,
        price: currentBooking.price
      })
    });
    
    if (!res.ok) throw new Error("Booking failed - network error.");
    
    const data = await res.json();
    alert("Success! " + data.message);
    $("#booking-modal").style.display = "none";

    // If there's a mock ticket link, open it to show the user the "email"
    if (data.ticket_url) {
      window.open(data.ticket_url, "_blank");
    }
  } catch(e) {
    alert("Error processing booking: " + e.message);
  } finally {
    btn.textContent = origText;
    btn.disabled = false;
  }
}

async function runPlan(e) {
  if (e) e.preventDefault();
  
  const locSel = $("#f-location").value;
  const loc = locSel === "Other" ? $("#f-location-other").value : locSel;
  const dStart = $("#f-date-start").value;
  const dEnd = $("#f-date-end").value;
  const budget = $("#f-budget").value;
  const vType = $("#f-type").value;
  const adults = $("#f-adults").value;
  const kids = $("#f-kids").value;
  
  const checkedActivities = Array.from(document.querySelectorAll('input[name="activity"]:checked')).map(cb => cb.value);
  
  if (!loc || !dStart || !dEnd || !budget || !vType) {
    $("#hero-status").textContent = "⚠️ Please fill all required fields.";
    return;
  }
  
  const q = `Trip to ${loc} for ${vType} from ${dStart} to ${dEnd}. Budget: ${budget}. Group: ${adults} adults, ${kids} kids. Preferred activities: ${checkedActivities.join(", ")}.`;

  $("#hero-status").textContent = "⏳ Fetching forecast, map data, and running agents…";
  $("#results-stack").hidden = true;
  if ($("#technical-fold")) $("#technical-fold").hidden = true;

  try {
    const res = await fetch("/api/plan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: q }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || res.statusText);
    }
    const data = await res.json();
    const trip = data.trip || {};
    const tech = data.technical_details || {};

    renderDestination(trip.destination_overview || {});
    renderForecast(trip.safe_marine_forecast || {});
    renderActivities(trip.recommended_activities || []);
    renderLogistics(trip.logistics_and_budget || {});
    renderGear(trip.equipment_and_operators || {});
    renderItinerary(trip.adaptive_itinerary || {});
    renderEmergency(trip.emergency_services || {});
    renderSummary(trip.trip_intelligence_summary || {}, trip.logistics_and_budget || {});
    renderVendors(trip.recommended_activities || [], trip.destination_overview || {});
    renderTechnical(tech);

    $("#results-stack").hidden = false;
    if ($("#technical-fold")) {
      $("#technical-fold").hidden = false;
      $("#technical-fold").open = false;
    }
    $("#hero-status").textContent = "Plan updated. Scroll for each section.";
    document.getElementById("sec-dest").scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (e) {
    $("#hero-status").textContent = "Something went wrong: " + e.message;
  }
}

document.addEventListener("DOMContentLoaded", () => {
  attachRipples();
  // login modal
  const loginBtn = $("#login-btn");
  const modal = $("#login-modal");
  const closeBtn = $("#close-login");
  const submitLogin = $("#submit-login");
  const loginInput = $("#login-input");
  const userProfile = $("#user-profile");
  const userDisplay = $("#user-display");
  const logoutBtn = $("#logout-btn");
  const loginErr = $("#login-err");

  if (loginBtn && modal) {
      loginBtn.addEventListener("click", () => {
          modal.hidden = false;
      });
      closeBtn.addEventListener("click", () => {
          modal.hidden = true;
          loginErr.hidden = true;
      });
      submitLogin.addEventListener("click", () => {
          const val = loginInput.value.trim();
          if (val.length < 5) {
              loginErr.textContent = "Please enter a valid email or phone number.";
              loginErr.hidden = false;
              return;
          }
          modal.hidden = true;
          loginBtn.style.display = "none";
          userProfile.hidden = false;
          userProfile.style.display = "flex";
          userDisplay.textContent = "👋 " + val;
      });
      logoutBtn.addEventListener("click", () => {
          userProfile.hidden = true;
          userProfile.style.display = "none";
          loginBtn.style.display = "inline-block";
          loginInput.value = "";
      });
  }

  // Nationality -> Visa
  const natSelect = $("#nationality-select");
  const visaLink = $("#visa-link");
  if (natSelect && visaLink) {
      natSelect.addEventListener("change", (e) => {
          if (e.target.value === "OTHER") {
              visaLink.style.display = "inline-block";
              visaLink.hidden = false;
          } else {
              visaLink.style.display = "none";
              visaLink.hidden = true;
          }
      });
  }
  
  if ($("#nav-mytrips")) $("#nav-mytrips").addEventListener("click", (e) => { e.preventDefault(); alert("Please login to view your trips."); });
  if ($("#nav-wishlist")) $("#nav-wishlist").addEventListener("click", (e) => { e.preventDefault(); alert("Please login to view your wishlist."); });

  
  const locSelect = $("#f-location");
  if (locSelect) {
    locSelect.addEventListener("change", (e) => {
      const otherInput = $("#f-location-other");
      if (e.target.value === "Other") {
        otherInput.style.display = "block";
        otherInput.required = true;
      } else {
        otherInput.style.display = "none";
        otherInput.required = false;
      }
    });
  }

  const form = $("#trip-form");
  if (form) {
    form.addEventListener("submit", runPlan);
  }

  const suggestForm = $("#suggest-form");
  if (suggestForm) {
    suggestForm.addEventListener("submit", runSuggest);
  }

  // Language Selection via Google Translate Widget Wrapper
  const langSelect = $("#language-select");
  if (langSelect) {
    langSelect.addEventListener("change", (e) => {
      const tSelect = document.querySelector(".goog-te-combo");
      if (tSelect) {
        tSelect.value = e.target.value;
        tSelect.dispatchEvent(new Event("change"));
      } else {
        setTimeout(() => {
          const retry = document.querySelector(".goog-te-combo");
          if (retry) {
            retry.value = e.target.value;
            retry.dispatchEvent(new Event("change"));
          }
        }, 1000);
      }
    });
  }
});

async function runSuggest(e) {
  if (e) e.preventDefault();
  
  const dStart = $("#s-date-start").value;
  const dEnd = $("#s-date-end").value;
  const budget = $("#s-budget").value;
  const vType = $("#s-type").value;
  const adults = $("#s-adults").value;
  const kids = $("#s-kids").value;
  
  const checkedActivities = Array.from(document.querySelectorAll('input[name="s-activity"]:checked')).map(cb => cb.value);
  
  if (!dStart || !dEnd || !budget || !vType || checkedActivities.length === 0) {
    $("#suggest-status").textContent = "⚠️ Please fill all required fields and select at least one activity.";
    return;
  }
  
  $("#suggest-status").textContent = "⏳ Analyzing database to find best matching cities...";
  $("#suggested-cities-panel").style.display = "none";
  $("#results-stack").hidden = true;
  if ($("#technical-fold")) $("#technical-fold").hidden = true;

  setTimeout(() => {
    // Generate Mock Recommendations based on Activities
    const defaultCities = [
      { name: "Palolem, Goa", desc: "A scenic crescent-shaped beach perfect for kayaking, boat tours, and relaxed family vacations. Moderate crowd with excellent safety logic.", match: 96 },
      { name: "Havelock, Andamans", desc: "The ultimate destination for Scuba Diving and Snorkeling. Pristine waters and world-class reef ecosystems. Higher budget required.", match: 92 },
      { name: "Varkala, Kerala", desc: "Unique cliff-side beaches ideal for surfing and relaxed stays. Great budget-friendly options and rich cultural immersion.", match: 85 }
    ];
    
    let html = "";
    defaultCities.forEach(city => {
      html += `
        <div class="vendor-card" style="cursor: pointer; border: 2px solid rgba(42,122,140,0.15); transition: border-color 0.2s, transform 0.2s;" onmouseover="this.style.borderColor='var(--sea-mid)'; this.style.transform='translateY(-2px)'" onmouseout="this.style.borderColor='rgba(42,122,140,0.15)'; this.style.transform='none'">
          <div class="vendor-header">
            <h4>📍 ${city.name}</h4>
            <span class="vendor-rating">${city.match}% Match</span>
          </div>
          <div class="vendor-details" style="margin-top: 0.5rem; margin-bottom: 1rem;">
            <p>${city.desc}</p>
          </div>
          <button type="button" class="btn-primary ripple-surface" style="font-size: 1rem; padding: 0.8rem;" onclick="selectSuggestedCity('${city.name}')">Select ${city.name.split(',')[0]} &amp; Build Plan</button>
        </div>
      `;
    });
    
    $("#out-suggested-cities").innerHTML = html;
    $("#suggested-cities-panel").style.display = "block";
    $("#suggest-status").textContent = "Recommendations generated. Choose a city to continue.";
    $("#suggested-cities-panel").scrollIntoView({ behavior: 'smooth' });
  }, 1000);
}

window.selectSuggestedCity = function(city) {
  // Transfer state to the primary known destination form visually
  const locSelect = $("#f-location");
  let optionExists = false;
  Array.from(locSelect.options).forEach(opt => {
    if (opt.value === city) optionExists = true;
  });
  
  if (optionExists) {
    locSelect.value = city;
    $("#f-location-other").style.display = "none";
  } else {
    locSelect.value = "Other";
    $("#f-location-other").style.display = "block";
    $("#f-location-other").value = city;
  }
  
  $("#f-date-start").value = $("#s-date-start").value;
  $("#f-date-end").value = $("#s-date-end").value;
  $("#f-budget").value = $("#s-budget").value;
  $("#f-type").value = $("#s-type").value;
  $("#f-adults").value = $("#s-adults").value;
  $("#f-kids").value = $("#s-kids").value;
  
  const sActs = Array.from(document.querySelectorAll('input[name="s-activity"]:checked')).map(cb => cb.value);
  document.querySelectorAll('input[name="activity"]').forEach(cb => {
    cb.checked = sActs.includes(cb.value);
  });
  
  // Switch visual tabs back to Known Destination
  document.getElementById('tab-btn-known').click();
  
  // Hide suggested cities panel
  $("#suggested-cities-panel").style.display = "none";
  
  // Instantly run the plan
  runPlan();
}

// --- Wishlist Logic ---
function getWishlist() {
  const w = localStorage.getItem("tidewise_wishlist");
  return w ? JSON.parse(w) : [];
}

function saveWishlist(w) {
  localStorage.setItem("tidewise_wishlist", JSON.stringify(w));
}

function isWishlisted(actName, vendorName) {
  const w = getWishlist();
  return w.some(item => item.activity === actName && item.vendor === vendorName);
}

window.toggleWishlist = function(btnEl, actName, vendorName, price, rating) {
  let w = getWishlist();
  const idx = w.findIndex(item => item.activity === actName && item.vendor === vendorName);
  
  if (idx > -1) {
    w.splice(idx, 1);
    btnEl.innerHTML = '🤍';
    btnEl.style.color = '#aaa';
  } else {
    w.push({ activity: actName, vendor: vendorName, price, rating });
    btnEl.innerHTML = '❤️';
    btnEl.style.color = '#e0845a';
    
    // Tiny animation feeling
    btnEl.style.transform = 'scale(1.2)';
    setTimeout(() => btnEl.style.transform = 'scale(1)', 200);
  }
  saveWishlist(w);
};

window.openWishlistModal = function() {
  const w = getWishlist();
  const body = document.getElementById('wishlist-body');
  
  if (w.length === 0) {
    body.innerHTML = '<p>Your wishlist is currently empty. Explore coastal activities and tap the heart icon to save them!</p>';
  } else {
    let html = '<div class="vendor-cards-row" style="display: flex; flex-direction: column; gap: 1rem;">';
    w.forEach((item, i) => {
      html += `
        <div class="vendor-card" style="display: flex; justify-content: space-between; align-items: center; padding: 1rem; width: 100%;">
          <div>
            <h4 style="margin:0 0 0.2rem 0; color:var(--sea-dark)">${item.vendor} <span class="vendor-rating" style="font-size:0.85em">⭐ ${item.rating}</span></h4>
            <p style="margin:0; font-size:0.9rem; color:#666;">Activity: <strong>${item.activity}</strong> | Price: ${item.price}</p>
          </div>
          <div style="display: flex; gap: 0.5rem; align-items: center;">
            <button class="btn-primary ripple-surface" style="padding: 0.4rem 0.8rem; font-size: 0.85rem;" onclick="openBookingModal('${item.activity}', '${item.vendor}', '${item.price}'); document.getElementById('wishlist-modal').style.display='none';">Book</button>
            <button class="btn-secondary" style="padding: 0.4rem; font-size: 0.85rem; background:#f5f8f9; border-color:#ccc; color:#555;" onclick="removeWishlistItem(${i})">❌</button>
          </div>
        </div>
      `;
    });
    html += '</div>';
    body.innerHTML = html;
  }
  
  document.getElementById('wishlist-modal').style.display = 'flex';
};

window.removeWishlistItem = function(index) {
  let w = getWishlist();
  if (index > -1 && index < w.length) {
    const removed = w.splice(index, 1)[0];
    saveWishlist(w);
    openWishlistModal(); // refresh UI
    
    // Force a re-render of current vendor list if button exists in DOM
    document.querySelectorAll('.wishlist-btn').forEach(btn => {
       if (btn.getAttribute('onclick').includes(removed.vendor) && btn.getAttribute('onclick').includes(removed.activity)) {
           btn.innerHTML = '🤍';
           btn.style.color = '#aaa';
       }
    });
  }
};



// --- Service Panel & Booking System ---
window.openServicePanel = function(type) {
  const titles = {
    flight: "Book Flights", hotel: "Book Hotels", bus: "Book Bus", 
    cruise: "Book Cruise", cab: "Book Cabs", tours: "Tours & Attractions", villas: "Villas & Homestays"
  };
  $("#sp-title").textContent = titles[type];
  $("#sp-type").value = type;
  $("#sp-results").style.display = "none";
  $("#service-panel-modal").style.display = "flex";
}

window.searchService = function() {
  const type = $("#sp-type").value;
  const loc = $("#sp-location").value;
  const date = $("#sp-date").value;
  
  if(!loc || !date) { alert("Location and Date required"); return; }
  
  const providers = {
    flight: ["IndiGo", "Air India", "SpiceJet"],
    hotel: ["Taj Exotica", "Marriott Resort", "Local Sea View Inn"],
    bus: ["Volvo Express", "Sleeper Lines", "Coastal Transports"],
    cruise: ["Oceania Cruises", "Coastal Ferries", "Luxury Yachts"],
    cab: ["Uber Coastal", "Ola Outstation", "Local Taxi Service"],
    tours: ["City Heritage", "Island Explorer", "Temple Trails"],
    villas: ["Oceanfront Villa", "Cozy Homestay", "Luxury Retreat"]
  };
  
  const basePrices = { flight: 4500, hotel: 3000, bus: 800, cruise: 6000, cab: 1500, tours: 1200, villas: 8000 };
  
  let html = '';
  providers[type].forEach((p, i) => {
    const price = `₹${basePrices[type] + i*500}`;
    html += `
      <div class="vendor-card" style="padding: 1rem; margin-bottom: 1rem; border: 1px solid #ccc; border-radius: 6px;">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <h4 style="margin:0">${p}</h4>
            <p style="margin:0; font-size: 0.9em;">Price: ${price}</p>
          </div>
          <button class="btn-primary" onclick="confirmServiceBooking('${type}', '${p}', '${price}')">Book Now</button>
        </div>
      </div>
    `;
  });
  
  $("#sp-results-list").innerHTML = html;
  $("#sp-results").style.display = "block";
}

window.confirmServiceBooking = async function(type, vendor, price) {
  const email = prompt("Enter your email for confirmation:");
  if(!email) return;
  const phone = prompt("Enter your phone number (optional):") || "";
  
  try {
    const res = await fetch(`/api/book/${type}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email, phone, vendor, price, 
        activity: type + " booking",
        date: $("#sp-date").value,
        location: $("#sp-location").value,
        people: parseInt($("#sp-people").value)
      })
    });
    const data = await res.json();
    alert("Success! " + data.message + " Booking ID: " + data.booking_id);
    $("#service-panel-modal").style.display = "none";
  } catch(e) {
    alert("Error: " + e.message);
  }
}

// --- Modify Plan ---
window.submitModifyPlan = async function() {
  const q = "Modified plan request.";
  const budget = $("#mod-budget").value;
  const acts = $("#mod-activities").value;
  
  const changes = {};
  if(budget) changes.budget = parseInt(budget);
  if(acts) changes.add_activities = acts.split(',').map(s=>s.trim());
  
  $("#hero-status").textContent = "⏳ Adaptive Planning Agent is recomputing your itinerary...";
  $("#modify-plan-modal").style.display = "none";
  document.getElementById("sec-dest").scrollIntoView({ behavior: "smooth", block: "start" });
  
  try {
    const res = await fetch("/api/plan/modify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: q, changes: changes })
    });
    const data = await res.json();
    const trip = data.trip || {};
    
    // We update only itinerary and budget sections visually to show "BEFORE vs AFTER" if we had the old state
    // But re-rendering the whole plan also achieves the instant recomputation goal.
    renderLogistics(trip.logistics_and_budget || {});
    renderItinerary(trip.adaptive_itinerary || {});
    renderSummary(trip.trip_intelligence_summary || {}, trip.logistics_and_budget || {});
    
    alert("Plan successfully modified!");
  } catch (e) {
    alert("Error modifying plan: " + e.message);
  }
}

// --- Fetch Budget Breakdown ---
window.fetchBudgetBreakdown = async function() {
  // Can be called to get dynamic breakdown
  const lb = window.current_logistics_budget; 
  if(!lb) return;
  const res = await fetch("/api/budget/breakdown", {
     method: "POST",
     headers: {"Content-Type": "application/json"},
     body: JSON.stringify({
         total_budget: lb.estimated_total_inr || 0,
         duration_days: 4,
         group_size: 2
     })
  });
  const data = await res.json();
  console.log("Detailed Breakdown:", data);
}
